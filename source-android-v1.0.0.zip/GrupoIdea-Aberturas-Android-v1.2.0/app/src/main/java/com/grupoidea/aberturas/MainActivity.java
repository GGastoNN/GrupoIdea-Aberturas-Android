package com.grupoidea.aberturas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT_GIC = 1001;
    private static final int REQ_EXPORT_GIP = 1002;
    private static final String CATALOG_CACHE = "catalogo_importado.gic";
    private static final String DRAFT_CACHE = "borrador_aberturas.json";

    private JSONObject catalogRoot;
    private final List<JSONObject> selectableSubtypes = new ArrayList<>();
    private final List<Opening> openings = new ArrayList<>();
    private final ProjectConfig projectConfig = new ProjectConfig();
    private String pendingExportJson;
    private String draftProjectName = "Proyecto móvil";
    private int editingIndex = -1;

    private TextView catalogStatus;
    private TextView summaryText;
    private TextView liveCalcText;
    private EditText projectName;
    private Spinner subtypeSpinner;
    private EditText openingName;
    private EditText widthMm;
    private EditText heightMm;
    private EditText quantity;
    private EditText crossbarsCount;
    private EditText notesField;
    private EditText frameWidthMm;
    private EditText frameDepthMm;
    private EditText leafSectionMm;
    private LinearLayout openingsContainer;
    private Button hingeLeftButton;
    private Button hingeRightButton;
    private Button inwardButton;
    private Button outwardButton;
    private DoorPreviewView previewView;
    private Button saveOpeningButton;

    private boolean suppressFieldSync;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Grupo Idea Aberturas");
        loadCachedCatalog();
        loadDraft();
        buildUi();
        refreshSubtypeSpinner();
        refreshOpenings();
        syncConfigToUi();
        refreshPreviewFromUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(244, 247, 250));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(headerCard());
        root.addView(actionMenu());
        root.addView(statusCard());
        root.addView(summaryCard());
        root.addView(projectSection());
        root.addView(configSection());
        root.addView(newOpeningSection());
        root.addView(openingsSection());
        root.addView(exportSection());

        setContentView(scroll);
    }

    private View headerCard() {
        LinearLayout card = cardContainer();
        card.setBackground(roundedDrawable(Color.WHITE, dp(20), 0xFFE0E6EC, 1));

        TextView title = text("Grupo Idea · Aberturas de chapa", 24, true);
        title.setTextColor(Color.rgb(26, 41, 57));
        TextView subtitle = text("Configurador visual móvil · APK interactivo · compatible con Cotizador Integral v5.5", 14, false);
        subtitle.setTextColor(Color.rgb(91, 108, 125));

        card.addView(title);
        card.addView(space(6));
        card.addView(subtitle);
        return card;
    }

    private View actionMenu() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(12), 0, dp(4));
        hsv.addView(row);

        row.addView(actionTile("Catálogo", "Importar .gic", android.R.drawable.ic_menu_upload, v -> chooseCatalog()));
        row.addView(actionTile("Proyecto", "Exportar .gip", android.R.drawable.ic_menu_save, v -> beginExport()));
        row.addView(actionTile("Abertura", "Guardar en lista", android.R.drawable.ic_input_add, v -> saveOpening()));
        row.addView(actionTile("Borrador", "Nuevo", android.R.drawable.ic_menu_revert, v -> resetForm()));
        row.addView(actionTile("Vista", "Actualizar", android.R.drawable.ic_popup_sync, v -> refreshPreviewFromUi()));
        return hsv;
    }

    private View statusCard() {
        LinearLayout card = cardContainer();
        card.setBackground(roundedDrawable(0xFFF8FBFF, dp(18), 0xFFD6E5F3, 1));
        card.addView(section("Catálogo"));
        catalogStatus = text("Catálogo: no cargado", 14, true);
        catalogStatus.setTextColor(Color.rgb(33, 87, 133));
        card.addView(catalogStatus);
        liveCalcText = text("Esperando datos para cálculo en vivo.", 13, false);
        liveCalcText.setTextColor(Color.rgb(77, 98, 119));
        liveCalcText.setPadding(0, dp(8), 0, 0);
        card.addView(liveCalcText);
        return card;
    }

    private View summaryCard() {
        LinearLayout card = cardContainer();
        card.addView(section("Resumen interactivo"));
        summaryText = text("0 aberturas · 0 unidades", 14, true);
        summaryText.setTextColor(Color.rgb(35, 86, 128));
        card.addView(summaryText);
        TextView note = text("Tocá Editar, Duplicar, Subir o Bajar para administrar el proyecto completo desde el teléfono.", 12, false);
        note.setTextColor(Color.rgb(94, 109, 124));
        note.setPadding(0, dp(6), 0, 0);
        card.addView(note);
        return card;
    }

    private View projectSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Proyecto"));
        projectName = input("Nombre del proyecto", draftProjectName);
        projectName.addTextChangedListener(simpleWatcher());
        card.addView(projectName, fullWidth());
        return card;
    }

    private View configSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Configurador técnico"));
        card.addView(text("Ajustá la abertura en tiempo real con controles, atajos y botones visuales.", 13, false));

        previewView = new DoorPreviewView(this);
        LinearLayout previewCard = new LinearLayout(this);
        previewCard.setOrientation(LinearLayout.VERTICAL);
        previewCard.setPadding(dp(12), dp(12), dp(12), dp(12));
        previewCard.setBackground(roundedDrawable(Color.WHITE, dp(18), 0xFFE3E8EE, 1));
        LinearLayout.LayoutParams pvlp = fullWidth();
        pvlp.topMargin = dp(10);
        previewCard.setLayoutParams(pvlp);
        previewCard.addView(previewView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320)));
        card.addView(previewCard);

        frameWidthMm = numeric("125", "125");
        frameDepthMm = numeric("40", "40");
        leafSectionMm = numeric("50", "50");

        card.addView(parameterCardWithSlider("Ancho de marco", "Sección vista del marco", android.R.drawable.ic_menu_crop,
                frameWidthMm, 50, 500, 5, new int[]{80, 100, 125, 150}));
        card.addView(parameterCardWithSlider("Espesor de marco", "Espesor lateral del marco", android.R.drawable.ic_menu_manage,
                frameDepthMm, 20, 200, 2, new int[]{30, 40, 50, 60}));
        card.addView(parameterCardWithSlider("Sección de hoja", "Perfil visible de la hoja", android.R.drawable.ic_menu_edit,
                leafSectionMm, 20, 200, 2, new int[]{40, 50, 60, 70}));

        card.addView(space(8));
        card.addView(sectionMini("Bisagras y apertura"));
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        hingeLeftButton = optionButton("Bisagra izq.", android.R.drawable.ic_media_previous, true, v -> {
            projectConfig.hingeLeft = true;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        hingeRightButton = optionButton("Bisagra der.", android.R.drawable.ic_media_next, false, v -> {
            projectConfig.hingeLeft = false;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        row1.addView(hingeLeftButton, weighted());
        row1.addView(hingeRightButton, weighted());
        card.addView(row1, fullWidth());

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(0, dp(6), 0, 0);
        inwardButton = optionButton("Abre interior", android.R.drawable.ic_menu_revert, true, v -> {
            projectConfig.opensInward = true;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        outwardButton = optionButton("Abre exterior", android.R.drawable.ic_menu_share, false, v -> {
            projectConfig.opensInward = false;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        row2.addView(inwardButton, weighted());
        row2.addView(outwardButton, weighted());
        card.addView(row2, fullWidth());

        refreshOptionButtons();
        return card;
    }

    private View newOpeningSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Nueva abertura / edición"));

        card.addView(label("Tipología de chapa"));
        subtypeSpinner = new Spinner(this);
        card.addView(subtypeSpinner, fullWidth());

        openingName = input("Identificación", "Abertura 1");
        notesField = input("Notas u observaciones", "");
        notesField.setMinLines(2);
        notesField.setSingleLine(false);
        bindSimpleRefresh(openingName);
        bindSimpleRefresh(notesField);
        card.addView(space(8));
        card.addView(openingName, fullWidth());

        widthMm = numeric("900", "900");
        heightMm = numeric("2100", "2100");
        quantity = numeric("1", "1");
        crossbarsCount = numeric("0", "0");

        card.addView(space(8));
        card.addView(parameterCardWithSlider("Ancho de abertura", "Dimensión de luz horizontal", android.R.drawable.ic_menu_directions,
                widthMm, 300, 3000, 10, new int[]{700, 800, 900, 1000, 1200}));
        card.addView(parameterCardWithSlider("Alto de abertura", "Dimensión de luz vertical", android.R.drawable.ic_menu_sort_by_size,
                heightMm, 600, 4000, 10, new int[]{2000, 2050, 2100, 2200}));
        card.addView(parameterCardWithSlider("Cantidad", "Cuántas iguales querés agregar", android.R.drawable.ic_menu_add,
                quantity, 1, 50, 1, new int[]{1, 2, 3, 5}));
        card.addView(parameterCardWithSlider("Travesaños", "Cantidad de travesaños horizontales", android.R.drawable.ic_menu_more,
                crossbarsCount, 0, 8, 1, new int[]{0, 1, 2, 3}));

        card.addView(space(8));
        card.addView(notesField, fullWidth());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(10), 0, 0);

        saveOpeningButton = primaryButton("Agregar abertura", android.R.drawable.ic_input_add);
        saveOpeningButton.setOnClickListener(v -> saveOpening());
        Button reset = secondaryButton("Nuevo / limpiar", android.R.drawable.ic_menu_revert);
        reset.setOnClickListener(v -> resetForm());
        actions.addView(saveOpeningButton, weighted());
        actions.addView(reset, weighted());
        card.addView(actions, fullWidth());
        return card;
    }

    private View openingsSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Aberturas del proyecto"));
        openingsContainer = new LinearLayout(this);
        openingsContainer.setOrientation(LinearLayout.VERTICAL);
        card.addView(openingsContainer, fullWidth());

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        Button clear = secondaryButton("Vaciar lista", android.R.drawable.ic_menu_delete);
        clear.setOnClickListener(v -> confirmClearProject());
        Button duplicateLast = secondaryButton("Duplicar última", android.R.drawable.ic_menu_set_as);
        duplicateLast.setOnClickListener(v -> duplicateLastOpening());
        row.addView(clear, weighted());
        row.addView(duplicateLast, weighted());
        card.addView(row, fullWidth());
        return card;
    }

    private View exportSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Exportación"));
        Button export = primaryButton("Exportar proyecto .gip", android.R.drawable.ic_menu_save);
        export.setOnClickListener(v -> beginExport());
        card.addView(export, fullWidth());
        card.addView(space(8));
        TextView note = text("Usá el mismo catálogo .gic en el escritorio para asegurar compatibilidad completa.", 12, false);
        note.setTextColor(Color.rgb(96, 108, 119));
        card.addView(note);
        return card;
    }

    private View actionTile(String title, String subtitle, int iconRes, View.OnClickListener onClick) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(14), dp(12), dp(14), dp(12));
        tile.setBackground(roundedDrawable(Color.WHITE, dp(18), 0xFFE0E6EC, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, dp(10), 0);
        tile.setLayoutParams(lp);
        tile.setClickable(true);
        tile.setOnClickListener(onClick);

        ImageView iv = new ImageView(this);
        iv.setImageResource(iconRes);
        iv.setColorFilter(Color.rgb(37, 114, 177));
        tile.addView(iv, new LinearLayout.LayoutParams(dp(28), dp(28)));
        tile.addView(space(6));
        TextView t1 = text(title, 15, true);
        TextView t2 = text(subtitle, 12, false);
        t2.setTextColor(Color.rgb(98, 111, 125));
        tile.addView(t1);
        tile.addView(t2);
        return tile;
    }

    private View parameterCardWithSlider(String title, String subtitle, int iconRes, EditText field, int min, int max, int step, int[] presets) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = fullWidth();
        lp.topMargin = dp(8);
        card.setLayoutParams(lp);
        card.setBackground(roundedDrawable(0xFFFDFEFE, dp(16), 0xFFE2E7EC, 1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setImageResource(iconRes);
        iv.setColorFilter(Color.rgb(42, 112, 169));
        header.addView(iv, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(10), 0, 0, 0);
        TextView t1 = text(title, 15, true);
        TextView t2 = text(subtitle, 12, false);
        t2.setTextColor(Color.rgb(105, 118, 132));
        texts.addView(t1);
        texts.addView(t2);
        header.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(header);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, 0);

        Button minus = miniStepButton("-" + step);
        minus.setOnClickListener(v -> adjustField(field, -step, min, max));
        Button plus = miniStepButton("+" + step);
        plus.setOnClickListener(v -> adjustField(field, step, min, max));

        TextView unit = text("mm", 14, true);
        if (max <= 60 && min >= 0) unit.setText("u.");
        unit.setPadding(dp(8), 0, 0, 0);

        row.addView(minus, new LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        fp.setMargins(dp(8), 0, dp(8), 0);
        row.addView(field, fp);
        row.addView(plus, new LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(unit);
        card.addView(row);

        SeekBar sb = new SeekBar(this);
        sb.setMax((max - min) / Math.max(1, step));
        sb.setProgress((clamp(parseOr(field, min), min, max) - min) / Math.max(1, step));
        sb.setPadding(0, dp(4), 0, 0);
        card.addView(sb, fullWidth());
        bindFieldAndSeekBar(field, sb, min, max, step);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(0, dp(4), 0, 0);
        hsv.addView(chips);
        for (int p : presets) {
            Button chip = presetButton(String.valueOf(p), v -> {
                field.setText(String.valueOf(clamp(p, min, max)));
                field.setSelection(field.getText().length());
                refreshPreviewFromUi();
            });
            chips.addView(chip);
        }
        card.addView(hsv);
        return card;
    }

    private Button presetButton(String label, View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12f);
        b.setBackground(roundedDrawable(0xFFF0F6FC, dp(14), 0xFFD5E3F2, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(onClick);
        return b;
    }

    private void bindFieldAndSeekBar(EditText field, SeekBar sb, int min, int max, int step) {
        field.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) {
                if (suppressFieldSync) return;
                int value = clamp(parseOr(field, min), min, max);
                suppressFieldSync = true;
                sb.setProgress((value - min) / Math.max(1, step));
                suppressFieldSync = false;
                refreshPreviewFromUi();
            }
        });

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || suppressFieldSync) return;
                int value = min + progress * Math.max(1, step);
                value = clamp(value, min, max);
                suppressFieldSync = true;
                field.setText(String.valueOf(value));
                field.setSelection(field.getText().length());
                suppressFieldSync = false;
                refreshPreviewFromUi();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }

    private Button optionButton(String label, int iconRes, boolean active, View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(8));
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
        b.setOnClickListener(onClick);
        styleOptionButton(b, active);
        return b;
    }

    private void refreshOptionButtons() {
        if (hingeLeftButton != null) styleOptionButton(hingeLeftButton, projectConfig.hingeLeft);
        if (hingeRightButton != null) styleOptionButton(hingeRightButton, !projectConfig.hingeLeft);
        if (inwardButton != null) styleOptionButton(inwardButton, projectConfig.opensInward);
        if (outwardButton != null) styleOptionButton(outwardButton, !projectConfig.opensInward);
    }

    private void styleOptionButton(Button b, boolean active) {
        int bg = active ? 0xFFDCEEFE : 0xFFF3F6F9;
        int border = active ? 0xFF5AA7E6 : 0xFFD8E0E7;
        int fg = active ? Color.rgb(24, 92, 145) : Color.rgb(58, 74, 88);
        b.setBackground(roundedDrawable(bg, dp(16), border, 1));
        b.setTextColor(fg);
        for (Drawable d : b.getCompoundDrawables()) if (d != null) d.setTint(fg);
    }

    private Button primaryButton(String text, int iconRes) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(roundedDrawable(0xFF2E7BC6, dp(16), 0xFF2E7BC6, 1));
        b.setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(8));
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        return b;
    }

    private Button secondaryButton(String text, int iconRes) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setBackground(roundedDrawable(0xFFF3F6F9, dp(16), 0xFFD8E0E7, 1));
        b.setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(8));
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        return b;
    }

    private Button miniStepButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setBackground(roundedDrawable(0xFFF3F6F9, dp(14), 0xFFD9E1E7, 1));
        return b;
    }

    private void chooseCatalog() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/octet-stream", "text/plain"});
        startActivityForResult(i, REQ_IMPORT_GIC);
    }

    private void saveOpening() {
        if (catalogRoot == null || selectableSubtypes.isEmpty()) {
            toast("Primero importá el catálogo .gic del Cotizador.");
            return;
        }
        syncConfigFromUi();
        int w = parsePositive(widthMm, "ancho");
        int h = parsePositive(heightMm, "alto");
        int q = parsePositive(quantity, "cantidad");
        int trav = parseNonNegative(crossbarsCount, "travesaños");
        if (w <= 0 || h <= 0 || q <= 0 || trav < 0) return;

        int pos = subtypeSpinner.getSelectedItemPosition();
        if (pos < 0 || pos >= selectableSubtypes.size()) {
            toast("Elegí una tipología.");
            return;
        }
        JSONObject st = selectableSubtypes.get(pos);
        Opening op = editingIndex >= 0 && editingIndex < openings.size() ? openings.get(editingIndex) : new Opening();
        if (op.id == null || op.id.isEmpty()) op.id = "mob-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        op.name = safeText(openingName.getText().toString(), "Abertura " + (openings.size() + 1));
        op.widthMm = w;
        op.heightMm = h;
        op.quantity = q;
        op.crossbarsCount = trav;
        op.notes = notesField.getText().toString().trim();
        op.subtypeId = st.optString("Id", "");
        op.subtypeName = st.optString("Nombre", "Tipología");
        op.type = st.optInt("Tipo", 0);
        op.frameWidthMm = projectConfig.frameWidthMm;
        op.frameDepthMm = projectConfig.frameDepthMm;
        op.leafSectionMm = projectConfig.leafSectionMm;
        op.hingeLeft = projectConfig.hingeLeft;
        op.opensInward = projectConfig.opensInward;
        if (editingIndex < 0) openings.add(op);
        toast(editingIndex >= 0 ? "Abertura actualizada." : "Abertura agregada al proyecto.");
        resetFormAfterSave();
    }

    private void resetFormAfterSave() {
        editingIndex = -1;
        openingName.setText("Abertura " + (openings.size() + 1));
        notesField.setText("");
        quantity.setText("1");
        projectConfig.crossbarsCount = 0;
        crossbarsCount.setText("0");
        if (saveOpeningButton != null) saveOpeningButton.setText("Agregar abertura");
        saveDraft();
        refreshOpenings();
        refreshPreviewFromUi();
    }

    private void beginExport() {
        if (catalogRoot == null) {
            toast("Importá primero el catálogo .gic.");
            return;
        }
        if (openings.isEmpty()) {
            toast("Agregá al menos una abertura.");
            return;
        }
        syncConfigFromUi();
        try {
            JSONObject gip = GipProjectBuilder.build(projectName.getText().toString(), catalogRoot, projectConfig, openings);
            pendingExportJson = gip.toString();
        } catch (JSONException ex) {
            toast("No se pudo generar el proyecto: " + ex.getMessage());
            return;
        }

        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, safeName(projectName.getText().toString()) + ".gip");
        startActivityForResult(i, REQ_EXPORT_GIP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_IMPORT_GIC) {
            importCatalog(uri);
        } else if (requestCode == REQ_EXPORT_GIP) {
            exportProject(uri);
        }
    }

    private void importCatalog(Uri uri) {
        try {
            String json = readAll(getContentResolver().openInputStream(uri));
            JSONObject root = new JSONObject(json);
            if (!"GRUPO_IDEA_CATALOG_GIC".equalsIgnoreCase(root.optString("Formato", ""))) {
                toast("El archivo no es un catálogo .gic válido de Grupo Idea.");
                return;
            }
            JSONArray types = root.optJSONArray("Tipologias");
            if (types == null || types.length() == 0) {
                toast("El catálogo no contiene tipologías.");
                return;
            }
            catalogRoot = root;
            applyCatalogDefaults(root.optJSONObject("Settings"));
            cacheCatalog(json);
            refreshSubtypeSpinner();
            refreshPreviewFromUi();
            toast("Catálogo importado correctamente.");
        } catch (Exception ex) {
            toast("No se pudo leer el .gic: " + ex.getMessage());
        }
    }

    private void exportProject(Uri uri) {
        if (pendingExportJson == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri, "w");
             OutputStreamWriter writer = new OutputStreamWriter(os, StandardCharsets.UTF_8)) {
            writer.write(pendingExportJson);
            writer.flush();
            toast("Proyecto .gip generado. Ya podés abrirlo en el Cotizador de PC.");
        } catch (Exception ex) {
            toast("No se pudo guardar el .gip: " + ex.getMessage());
        } finally {
            pendingExportJson = null;
        }
    }

    private void refreshSubtypeSpinner() {
        selectableSubtypes.clear();
        List<String> labels = new ArrayList<>();
        if (catalogRoot != null) {
            JSONArray all = catalogRoot.optJSONArray("Tipologias");
            List<JSONObject> fallback = new ArrayList<>();
            if (all != null) {
                for (int i = 0; i < all.length(); i++) {
                    JSONObject st = all.optJSONObject(i);
                    if (st == null) continue;
                    fallback.add(st);
                    if (hasConformedSheet(st)) selectableSubtypes.add(st);
                }
            }
            if (selectableSubtypes.isEmpty()) selectableSubtypes.addAll(fallback);
        }
        for (JSONObject st : selectableSubtypes) labels.add(st.optString("Nombre", st.optString("Id", "Tipología")));
        if (labels.isEmpty()) labels.add("Importá un catálogo .gic");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subtypeSpinner.setAdapter(adapter);
        updateCatalogStatus();
    }

    private boolean hasConformedSheet(JSONObject subtype) {
        JSONArray parts = subtype.optJSONArray("Partes");
        if (parts == null) return false;
        for (int i = 0; i < parts.length(); i++) {
            JSONObject p = parts.optJSONObject(i);
            if (p != null && p.optInt("Geometria", 0) == 2) return true;
        }
        return false;
    }

    private void updateCatalogStatus() {
        if (catalogStatus == null) return;
        if (catalogRoot == null) {
            catalogStatus.setText("Catálogo: no cargado");
            return;
        }
        String hash = catalogRoot.optString("Hash", "");
        if (hash.length() > 12) hash = hash.substring(0, 12) + "…";
        catalogStatus.setText("Catálogo cargado · " + selectableSubtypes.size() + " tipologías de chapa · hash " + hash);
    }

    private void refreshOpenings() {
        if (openingsContainer == null) return;
        openingsContainer.removeAllViews();
        if (openings.isEmpty()) {
            TextView none = text("Todavía no hay aberturas cargadas.", 13, false);
            none.setPadding(0, dp(8), 0, dp(10));
            openingsContainer.addView(none);
            refreshSummary();
            return;
        }
        for (int i = 0; i < openings.size(); i++) {
            final int index = i;
            Opening op = openings.get(i);
            LinearLayout row = cardContainer();
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(roundedDrawable(Color.WHITE, dp(16), 0xFFE2E8EE, 1));

            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            ImageView icon = new ImageView(this);
            icon.setImageResource(android.R.drawable.ic_menu_agenda);
            icon.setColorFilter(Color.rgb(39, 112, 171));
            top.addView(icon, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView info = text(op.name + " · " + op.widthMm + "×" + op.heightMm + " mm · x" + op.quantity, 14, true);
            info.setPadding(dp(8), 0, 0, 0);
            top.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(top);

            TextView sub = text(op.subtypeName, 13, false);
            sub.setTextColor(Color.rgb(95, 108, 122));
            sub.setPadding(0, dp(6), 0, dp(2));
            row.addView(sub);

            String extra = "Marco " + op.frameWidthMm + " · Espesor " + op.frameDepthMm + " · Hoja " + op.leafSectionMm +
                    " · Travesaños " + op.crossbarsCount + " · " + (op.hingeLeft ? "Bisagra izq." : "Bisagra der.");
            TextView meta = text(extra, 12, false);
            meta.setTextColor(Color.rgb(110, 122, 136));
            row.addView(meta);
            if (op.notes != null && !op.notes.trim().isEmpty()) {
                TextView nts = text("Nota: " + op.notes.trim(), 12, false);
                nts.setPadding(0, dp(4), 0, 0);
                nts.setTextColor(Color.rgb(90, 101, 114));
                row.addView(nts);
            }

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setPadding(0, dp(8), 0, 0);
            Button edit = secondaryButton("Editar", android.R.drawable.ic_menu_edit);
            edit.setOnClickListener(v -> loadOpeningForEdit(index));
            Button dup = secondaryButton("Duplicar", android.R.drawable.ic_menu_set_as);
            dup.setOnClickListener(v -> duplicateOpening(index));
            actions.addView(edit, weighted());
            actions.addView(dup, weighted());
            row.addView(actions, fullWidth());

            LinearLayout actions2 = new LinearLayout(this);
            actions2.setOrientation(LinearLayout.HORIZONTAL);
            actions2.setPadding(0, dp(6), 0, 0);
            Button up = secondaryButton("Subir", android.R.drawable.arrow_up_float);
            up.setOnClickListener(v -> moveOpening(index, -1));
            Button down = secondaryButton("Bajar", android.R.drawable.arrow_down_float);
            down.setOnClickListener(v -> moveOpening(index, 1));
            Button del = secondaryButton("Eliminar", android.R.drawable.ic_menu_delete);
            del.setOnClickListener(v -> {
                openings.remove(index);
                if (editingIndex == index) editingIndex = -1;
                saveDraft();
                refreshOpenings();
                refreshPreviewFromUi();
            });
            actions2.addView(up, weightedThird());
            actions2.addView(down, weightedThird());
            actions2.addView(del, weightedThird());
            row.addView(actions2, fullWidth());
            openingsContainer.addView(row, fullWidth());
        }
        refreshSummary();
    }

    private void refreshSummary() {
        int totalUnits = 0;
        int totalAreaMm2 = 0;
        for (Opening op : openings) {
            totalUnits += Math.max(1, op.quantity);
            totalAreaMm2 += op.widthMm * op.heightMm * Math.max(1, op.quantity);
        }
        if (summaryText != null) {
            float totalM2 = totalAreaMm2 / 1_000_000f;
            summaryText.setText(openings.size() + " aberturas · " + totalUnits + " unidades · área aprox. " + String.format(Locale.US, "%.2f", totalM2) + " m²");
        }
    }

    private void refreshLiveCalculations(int openW, int openH) {
        int trav = clamp(parseOr(crossbarsCount, 0), 0, 8);
        int clearW = Math.max(0, openW - projectConfig.frameWidthMm * 2);
        int clearH = Math.max(0, openH - projectConfig.frameWidthMm * 2);
        String txt = "Vista previa: luz útil aprox. " + clearW + " × " + clearH + " mm · travesaños: " + trav +
                " · sentido: " + (projectConfig.opensInward ? "interior" : "exterior");
        if (liveCalcText != null) liveCalcText.setText(txt);
    }

    private void adjustField(EditText field, int delta, int min, int max) {
        int cur = parseOr(field, min);
        cur += delta;
        if (cur < min) cur = min;
        if (cur > max) cur = max;
        field.setText(String.valueOf(cur));
        field.setSelection(field.getText().length());
        refreshPreviewFromUi();
    }

    private void applyCatalogDefaults(JSONObject s) {
        if (s == null) return;
        projectConfig.frameWidthMm = (int) Math.round(s.optDouble("SeccionMarcoMM", projectConfig.frameWidthMm));
        projectConfig.frameDepthMm = (int) Math.round(s.optDouble("EspesorLateralMarcoMM", projectConfig.frameDepthMm));
        projectConfig.leafSectionMm = (int) Math.round(s.optDouble("SeccionHojaMM", projectConfig.leafSectionMm));
        syncConfigToUi();
    }

    private void syncConfigToUi() {
        if (frameWidthMm != null) frameWidthMm.setText(String.valueOf(projectConfig.frameWidthMm));
        if (frameDepthMm != null) frameDepthMm.setText(String.valueOf(projectConfig.frameDepthMm));
        if (leafSectionMm != null) leafSectionMm.setText(String.valueOf(projectConfig.leafSectionMm));
        if (crossbarsCount != null) crossbarsCount.setText(String.valueOf(projectConfig.crossbarsCount));
        refreshOptionButtons();
    }

    private void syncConfigFromUi() {
        projectConfig.frameWidthMm = clamp(parseOr(frameWidthMm, projectConfig.frameWidthMm), 50, 500);
        projectConfig.frameDepthMm = clamp(parseOr(frameDepthMm, projectConfig.frameDepthMm), 20, 200);
        projectConfig.leafSectionMm = clamp(parseOr(leafSectionMm, projectConfig.leafSectionMm), 20, 200);
        projectConfig.crossbarsCount = clamp(parseOr(crossbarsCount, projectConfig.crossbarsCount), 0, 8);
    }

    private void refreshPreviewFromUi() {
        syncConfigFromUi();
        int w = clamp(parseOr(widthMm, 900), 300, 3000);
        int h = clamp(parseOr(heightMm, 2100), 600, 4000);
        if (previewView != null) previewView.setModel(w, h, projectConfig);
        refreshLiveCalculations(w, h);
        saveDraft();
    }

    private void confirmClearProject() {
        new AlertDialog.Builder(this)
                .setTitle("Vaciar proyecto")
                .setMessage("Se eliminarán todas las aberturas cargadas. ¿Continuar?")
                .setPositiveButton("Sí", (d, which) -> {
                    openings.clear();
                    editingIndex = -1;
                    saveDraft();
                    refreshOpenings();
                    refreshPreviewFromUi();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void duplicateLastOpening() {
        if (openings.isEmpty()) {
            toast("No hay aberturas para duplicar.");
            return;
        }
        duplicateOpening(openings.size() - 1);
    }

    private void duplicateOpening(int index) {
        if (index < 0 || index >= openings.size()) return;
        Opening src = openings.get(index);
        Opening copy = Opening.fromJson(copyJson(src));
        copy.id = "mob-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        copy.name = src.name + " copia";
        openings.add(index + 1, copy);
        saveDraft();
        refreshOpenings();
        toast("Abertura duplicada.");
    }

    private JSONObject copyJson(Opening src) {
        try { return src.toJson(); }
        catch (Exception ex) { return new JSONObject(); }
    }

    private void moveOpening(int index, int delta) {
        int target = index + delta;
        if (index < 0 || index >= openings.size() || target < 0 || target >= openings.size()) return;
        Opening op = openings.remove(index);
        openings.add(target, op);
        saveDraft();
        refreshOpenings();
    }

    private void loadOpeningForEdit(int index) {
        if (index < 0 || index >= openings.size()) return;
        Opening op = openings.get(index);
        editingIndex = index;
        openingName.setText(op.name);
        widthMm.setText(String.valueOf(op.widthMm));
        heightMm.setText(String.valueOf(op.heightMm));
        quantity.setText(String.valueOf(op.quantity));
        crossbarsCount.setText(String.valueOf(op.crossbarsCount));
        notesField.setText(op.notes == null ? "" : op.notes);
        frameWidthMm.setText(String.valueOf(op.frameWidthMm));
        frameDepthMm.setText(String.valueOf(op.frameDepthMm));
        leafSectionMm.setText(String.valueOf(op.leafSectionMm));
        projectConfig.frameWidthMm = op.frameWidthMm;
        projectConfig.frameDepthMm = op.frameDepthMm;
        projectConfig.leafSectionMm = op.leafSectionMm;
        projectConfig.crossbarsCount = op.crossbarsCount;
        projectConfig.hingeLeft = op.hingeLeft;
        projectConfig.opensInward = op.opensInward;
        selectSubtype(op.subtypeId);
        refreshOptionButtons();
        if (saveOpeningButton != null) saveOpeningButton.setText("Actualizar abertura");
        refreshPreviewFromUi();
        toast("Editando abertura " + (index + 1));
    }

    private void selectSubtype(String subtypeId) {
        if (subtypeSpinner == null || subtypeId == null) return;
        for (int i = 0; i < selectableSubtypes.size(); i++) {
            if (subtypeId.equalsIgnoreCase(selectableSubtypes.get(i).optString("Id", ""))) {
                subtypeSpinner.setSelection(i);
                return;
            }
        }
    }

    private void resetForm() {
        editingIndex = -1;
        if (saveOpeningButton != null) saveOpeningButton.setText("Agregar abertura");
        openingName.setText("Abertura " + (openings.size() + 1));
        widthMm.setText("900");
        heightMm.setText("2100");
        quantity.setText("1");
        projectConfig.crossbarsCount = 0;
        crossbarsCount.setText("0");
        notesField.setText("");
        refreshPreviewFromUi();
    }

    private void cacheCatalog(String json) {
        try (FileOutputStream fos = openFileOutput(CATALOG_CACHE, MODE_PRIVATE)) {
            fos.write(json.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    private void loadCachedCatalog() {
        try (FileInputStream fis = openFileInput(CATALOG_CACHE)) {
            String json = readAll(fis);
            JSONObject root = new JSONObject(json);
            if ("GRUPO_IDEA_CATALOG_GIC".equalsIgnoreCase(root.optString("Formato", ""))) {
                catalogRoot = root;
                applyCatalogDefaults(root.optJSONObject("Settings"));
            }
        } catch (Exception ignored) { }
    }

    private void saveDraft() {
        try {
            JSONObject root = new JSONObject();
            root.put("projectName", projectName != null ? projectName.getText().toString() : draftProjectName);
            root.put("config", projectConfig.toJson());
            root.put("editingIndex", editingIndex);
            JSONArray arr = new JSONArray();
            for (Opening op : openings) arr.put(op.toJson());
            root.put("openings", arr);
            try (FileOutputStream fos = openFileOutput(DRAFT_CACHE, MODE_PRIVATE)) {
                fos.write(root.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { }
    }

    private void loadDraft() {
        try (FileInputStream fis = openFileInput(DRAFT_CACHE)) {
            String raw = readAll(fis);
            openings.clear();
            JSONObject root = new JSONObject(raw);
            projectConfig.copyFrom(ProjectConfig.fromJson(root.optJSONObject("config")));
            JSONArray arr = root.optJSONArray("openings");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o != null) openings.add(Opening.fromJson(o));
                }
            }
            draftProjectName = root.optString("projectName", "Proyecto móvil");
            editingIndex = root.optInt("editingIndex", -1);
        } catch (Exception ignored) { }
    }

    private void bindSimpleRefresh(EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) { if (!suppressFieldSync) refreshPreviewFromUi(); }
        });
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) throw new IllegalStateException("No se pudo abrir el archivo.");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) >= 0) sb.append(buf, 0, n);
        }
        return sb.toString();
    }

    private int parsePositive(EditText e, String field) {
        try {
            int v = Integer.parseInt(e.getText().toString().trim());
            if (v <= 0) throw new NumberFormatException();
            return v;
        } catch (Exception ex) {
            toast("Ingresá un valor válido para " + field + ".");
            e.requestFocus();
            return -1;
        }
    }

    private int parseNonNegative(EditText e, String field) {
        try {
            int v = Integer.parseInt(e.getText().toString().trim());
            if (v < 0) throw new NumberFormatException();
            return v;
        } catch (Exception ex) {
            toast("Ingresá un valor válido para " + field + ".");
            e.requestFocus();
            return -1;
        }
    }

    private int parseOr(EditText e, int fallback) {
        if (e == null) return fallback;
        try { return Integer.parseInt(e.getText().toString().trim()); }
        catch (Exception ex) { return fallback; }
    }

    private int clamp(int x, int min, int max) {
        return Math.max(min, Math.min(max, x));
    }

    private TextWatcher simpleWatcher() {
        return new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) { if (!suppressFieldSync) refreshPreviewFromUi(); }
        };
    }

    private TextView section(String s) {
        TextView t = text(s, 18, true);
        t.setPadding(0, 0, 0, dp(8));
        return t;
    }

    private TextView sectionMini(String s) {
        TextView t = text(s, 14, true);
        t.setPadding(0, dp(2), 0, dp(8));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, true);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(28, 37, 48));
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private EditText input(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setText(value);
        e.setPadding(dp(12), dp(12), dp(12), dp(12));
        e.setBackground(roundedDrawable(Color.WHITE, dp(14), 0xFFD8E0E7, 1));
        return e;
    }

    private EditText numeric(String hint, String value) {
        EditText e = input(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSelectAllOnFocus(true);
        e.setGravity(Gravity.CENTER_HORIZONTAL);
        return e;
    }

    private LinearLayout cardContainer() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = fullWidth();
        lp.topMargin = dp(12);
        card.setLayoutParams(lp);
        card.setBackground(roundedDrawable(Color.WHITE, dp(18), 0xFFE2E8EE, 1));
        return card;
    }

    private GradientDrawable roundedDrawable(int bg, int radius, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg);
        d.setCornerRadius(radius);
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private View space(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(dp)));
        return v;
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private LinearLayout.LayoutParams weightedThird() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private String safeName(String s) {
        if (s == null || s.trim().isEmpty()) return "Proyecto_movil";
        return s.trim().replaceAll("[^a-zA-Z0-9._-]+", "_");
    }

    private String safeText(String s, String fallback) {
        return s == null || s.trim().isEmpty() ? fallback : s.trim();
    }
}
