package com.grupoidea.aberturas;

import org.json.JSONException;
import org.json.JSONObject;

final class ProjectConfig {
    int frameWidthMm = 125;
    int frameDepthMm = 40;
    int leafSectionMm = 50;
    int crossbarsCount = 0;
    boolean hingeLeft = true;
    boolean opensInward = true;

    void copyFrom(ProjectConfig other) {
        if (other == null) return;
        frameWidthMm = other.frameWidthMm;
        frameDepthMm = other.frameDepthMm;
        leafSectionMm = other.leafSectionMm;
        crossbarsCount = other.crossbarsCount;
        hingeLeft = other.hingeLeft;
        opensInward = other.opensInward;
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("frameWidthMm", frameWidthMm);
        o.put("frameDepthMm", frameDepthMm);
        o.put("leafSectionMm", leafSectionMm);
        o.put("crossbarsCount", crossbarsCount);
        o.put("hingeLeft", hingeLeft);
        o.put("opensInward", opensInward);
        return o;
    }

    static ProjectConfig fromJson(JSONObject o) {
        ProjectConfig c = new ProjectConfig();
        if (o == null) return c;
        c.frameWidthMm = Math.max(50, o.optInt("frameWidthMm", c.frameWidthMm));
        c.frameDepthMm = Math.max(20, o.optInt("frameDepthMm", c.frameDepthMm));
        c.leafSectionMm = Math.max(20, o.optInt("leafSectionMm", c.leafSectionMm));
        c.crossbarsCount = Math.max(0, o.optInt("crossbarsCount", c.crossbarsCount));
        c.hingeLeft = o.optBoolean("hingeLeft", c.hingeLeft);
        c.opensInward = o.optBoolean("opensInward", c.opensInward);
        return c;
    }
}
