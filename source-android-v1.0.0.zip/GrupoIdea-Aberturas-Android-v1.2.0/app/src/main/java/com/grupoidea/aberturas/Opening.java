package com.grupoidea.aberturas;

import org.json.JSONException;
import org.json.JSONObject;

final class Opening {
    String id;
    String name;
    int widthMm;
    int heightMm;
    int quantity;
    int crossbarsCount;
    String notes;
    String subtypeId;
    String subtypeName;
    int type;
    int frameWidthMm;
    int frameDepthMm;
    int leafSectionMm;
    boolean hingeLeft;
    boolean opensInward;

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("widthMm", widthMm);
        o.put("heightMm", heightMm);
        o.put("quantity", quantity);
        o.put("crossbarsCount", crossbarsCount);
        o.put("notes", notes);
        o.put("subtypeId", subtypeId);
        o.put("subtypeName", subtypeName);
        o.put("type", type);
        o.put("frameWidthMm", frameWidthMm);
        o.put("frameDepthMm", frameDepthMm);
        o.put("leafSectionMm", leafSectionMm);
        o.put("hingeLeft", hingeLeft);
        o.put("opensInward", opensInward);
        return o;
    }

    static Opening fromJson(JSONObject o) {
        Opening x = new Opening();
        x.id = o.optString("id", "");
        x.name = o.optString("name", "Abertura");
        x.widthMm = o.optInt("widthMm", 900);
        x.heightMm = o.optInt("heightMm", 2100);
        x.quantity = Math.max(1, o.optInt("quantity", 1));
        x.crossbarsCount = Math.max(0, o.optInt("crossbarsCount", 0));
        x.notes = o.optString("notes", "");
        x.subtypeId = o.optString("subtypeId", "");
        x.subtypeName = o.optString("subtypeName", "");
        x.type = o.optInt("type", 0);
        x.frameWidthMm = Math.max(50, o.optInt("frameWidthMm", 125));
        x.frameDepthMm = Math.max(20, o.optInt("frameDepthMm", 40));
        x.leafSectionMm = Math.max(20, o.optInt("leafSectionMm", 50));
        x.hingeLeft = o.optBoolean("hingeLeft", true);
        x.opensInward = o.optBoolean("opensInward", true);
        return x;
    }
}
