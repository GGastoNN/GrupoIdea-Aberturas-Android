package com.grupoidea.aberturas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class DoorPreviewView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint accent = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint helper = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int openingWidthMm = 900;
    private int openingHeightMm = 2100;
    private ProjectConfig config = new ProjectConfig();

    public DoorPreviewView(Context context) {
        super(context);
        init();
    }

    public DoorPreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2f));
        stroke.setColor(Color.rgb(52, 73, 94));
        text.setColor(Color.rgb(37, 48, 61));
        text.setTextSize(dp(11f));
        accent.setStyle(Paint.Style.STROKE);
        accent.setStrokeWidth(dp(2.5f));
        accent.setColor(Color.rgb(40, 121, 187));
        helper.setStyle(Paint.Style.STROKE);
        helper.setStrokeWidth(dp(1.3f));
        helper.setColor(Color.rgb(176, 188, 199));
    }

    public void setModel(int openingWidthMm, int openingHeightMm, ProjectConfig config) {
        this.openingWidthMm = Math.max(100, openingWidthMm);
        this.openingHeightMm = Math.max(100, openingHeightMm);
        if (config != null) this.config = config;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int desiredW = (int) dp(320f);
        int desiredH = (int) dp(320f);
        int w = resolveSize(desiredW, widthMeasureSpec);
        int h = resolveSize(desiredH, heightMeasureSpec);
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth();
        float h = getHeight();
        c.drawColor(Color.WHITE);

        float pad = dp(14f);
        float top = dp(26f);
        float bottomLabelSpace = dp(56f);
        float availW = w - pad * 2;
        float availH = h - top - pad - bottomLabelSpace;
        float ratio = Math.min(availW / openingWidthMm, availH / openingHeightMm);
        float frameW = openingWidthMm * ratio;
        float frameH = openingHeightMm * ratio;
        float left = (w - frameW) / 2f;
        float right = left + frameW;
        float bottom = top + frameH;

        fill.setColor(Color.rgb(247, 250, 252));
        c.drawRoundRect(left, top, right, bottom, dp(8f), dp(8f), fill);
        stroke.setColor(Color.rgb(220, 228, 235));
        c.drawRoundRect(left, top, right, bottom, dp(8f), dp(8f), stroke);

        float frameFace = clamp(config.frameWidthMm * ratio, dp(9f), frameW * 0.18f);
        fill.setColor(Color.rgb(108, 128, 145));
        c.drawRect(left, top, right, top + frameFace, fill);
        c.drawRect(left, bottom - frameFace, right, bottom, fill);
        c.drawRect(left, top, left + frameFace, bottom, fill);
        c.drawRect(right - frameFace, top, right, bottom, fill);

        float gap = dp(5f);
        float leafLeft = left + frameFace + gap;
        float leafTop = top + frameFace + gap;
        float leafRight = right - frameFace - gap;
        float leafBottom = bottom - frameFace - gap;

        fill.setColor(Color.rgb(223, 231, 237));
        c.drawRoundRect(leafLeft, leafTop, leafRight, leafBottom, dp(6f), dp(6f), fill);
        stroke.setColor(Color.rgb(64, 81, 99));
        c.drawRoundRect(leafLeft, leafTop, leafRight, leafBottom, dp(6f), dp(6f), stroke);

        float leafSec = clamp(config.leafSectionMm * ratio * 0.45f, dp(4f), frameW * 0.08f);
        fill.setColor(Color.rgb(193, 207, 217));
        if (config.hingeLeft) {
            c.drawRect(leafLeft, leafTop, leafLeft + leafSec, leafBottom, fill);
        } else {
            c.drawRect(leafRight - leafSec, leafTop, leafRight, leafBottom, fill);
        }

        if (config.crossbarsCount > 0) {
            stroke.setColor(Color.rgb(104, 123, 139));
            fill.setColor(Color.rgb(175, 190, 202));
            float usable = leafBottom - leafTop;
            int spans = config.crossbarsCount + 1;
            for (int i = 1; i <= config.crossbarsCount; i++) {
                float y = leafTop + usable * i / spans;
                c.drawRect(leafLeft, y - dp(3f), leafRight, y + dp(3f), fill);
                c.drawLine(leafLeft, y, leafRight, y, stroke);
            }
        }

        float hingeX = config.hingeLeft ? leafLeft - dp(4f) : leafRight + dp(4f);
        fill.setColor(Color.rgb(214, 155, 44));
        for (int i = 0; i < 3; i++) {
            float yy = leafTop + (leafBottom - leafTop) * (0.18f + i * 0.31f);
            c.drawRoundRect(hingeX - dp(4f), yy - dp(8f), hingeX + dp(4f), yy + dp(8f), dp(3f), dp(3f), fill);
        }

        float pivotX = config.hingeLeft ? leafLeft : leafRight;
        float pivotY = (leafTop + leafBottom) / 2f;
        float arcR = Math.min(frameW, frameH) * 0.28f;
        float startAngle = config.hingeLeft ? -40f : 220f;
        float sweep = config.opensInward ? 55f : -55f;
        Path p = new Path();
        RectF arc = new RectF(pivotX - arcR, pivotY - arcR, pivotX + arcR, pivotY + arcR);
        p.addArc(arc, startAngle, sweep);
        c.drawPath(p, accent);
        float endAng = (float) Math.toRadians(startAngle + sweep);
        float endX = pivotX + (float) Math.cos(endAng) * arcR;
        float endY = pivotY + (float) Math.sin(endAng) * arcR;
        drawArrowHead(c, endX, endY, endAng + (sweep >= 0 ? 1f : -1f) * 0.15f);

        helper.setColor(Color.rgb(196, 205, 214));
        c.drawLine(left, top - dp(8f), right, top - dp(8f), helper);
        c.drawLine(left, bottom + dp(8f), right, bottom + dp(8f), helper);
        c.drawText(openingWidthMm + " mm", left, dp(16f), text);
        c.drawText(openingHeightMm + " mm alto", left, bottom + dp(24f), text);
        c.drawText("Marco " + config.frameWidthMm + " · Espesor " + config.frameDepthMm + " · Hoja " + config.leafSectionMm + " mm", left, bottom + dp(38f), text);
        c.drawText("Travesaños: " + config.crossbarsCount + " · " + (config.hingeLeft ? "Bisagra izq." : "Bisagra der.") + " · " + (config.opensInward ? "Abre interior" : "Abre exterior"), left, bottom + dp(52f), text);
    }

    private void drawArrowHead(Canvas c, float x, float y, float angleRad) {
        float len = dp(8f);
        float a1 = angleRad + (float) Math.toRadians(150);
        float a2 = angleRad - (float) Math.toRadians(150);
        c.drawLine(x, y, x + (float) Math.cos(a1) * len, y + (float) Math.sin(a1) * len, accent);
        c.drawLine(x, y, x + (float) Math.cos(a2) * len, y + (float) Math.sin(a2) * len, accent);
    }

    private float clamp(float x, float min, float max) {
        return Math.max(min, Math.min(max, x));
    }

    private float dp(float n) {
        return n * getResources().getDisplayMetrics().density;
    }
}
