# Grupo Idea Aberturas Android v1.2.0

Aplicación Android compañera de **Grupo Idea Cotizador Integral v5.5**.

## Novedades de la v1.2.0

- Configurador visual más dinámico.
- Controles directos para:
  - **Ancho de marco** (`SeccionMarcoMM`)
  - **Espesor de marco** (`EspesorLateralMarcoMM`)
  - **Sección de hoja** (`SeccionHojaMM`)
- Vista previa técnica en tiempo real de la abertura.
- Botones y menús con iconografía visual.
- Selector visual de lado de bisagra y sentido de apertura.
- Persistencia del borrador del proyecto móvil.
- Exportación de `.gip` esquema 6 compatible con el escritorio.

- Sliders interactivos y presets rápidos para dimensiones y secciones.
- Gestión completa de la lista: editar, duplicar, subir, bajar y eliminar.
- Campo de travesaños y notas por abertura.
- Resumen del proyecto y cálculo visual en vivo.
- Cada abertura conserva su configuración local para revisión en el teléfono.

## Flujo de uso

1. Importar catálogo `.gic` exportado desde el software de escritorio.
2. Ajustar parámetros globales del proyecto.
3. Elegir tipología de chapa.
4. Cargar ancho, alto y cantidad de cada abertura.
5. Agregar una o más aberturas al proyecto.
6. Exportar el proyecto `.gip`.
7. Abrir el `.gip` en el Cotizador Integral de escritorio.

## Compatibilidad

- El APK exporta proyectos `.gip` **esquema 6**.
- Conserva `CatalogHash` y `SubtipoId`.
- El cálculo final de fabricación sigue resolviéndose en el software de escritorio.
