# Mejoras incluidas en la v1.2.0

Esta iteración amplía el APK móvil con una interfaz mucho más interactiva:

- Vista previa técnica ampliada de la abertura.
- Sliders para ancho de marco, espesor de marco, sección de hoja, ancho, alto, cantidad y travesaños.
- Presets rápidos por botones para valores comunes.
- Gestión completa de aberturas cargadas:
  - editar
  - duplicar
  - subir
  - bajar
  - eliminar
- Notas por abertura.
- Resumen del proyecto y área estimada.
- Estado vivo con cálculo visual de luz útil aproximada.
- Persistencia del borrador local.
- Conservación de configuración local por cada abertura en el borrador.
- Exportación `.gip` compatible con el escritorio.

## Limitación conocida

El formato `.gip` del escritorio sigue trabajando con `Settings` globales del proyecto para marco/hoja.
Por eso, la exportación usa la configuración global vigente al momento de exportar.
Las configuraciones por abertura quedan guardadas en el borrador móvil para edición interactiva.
