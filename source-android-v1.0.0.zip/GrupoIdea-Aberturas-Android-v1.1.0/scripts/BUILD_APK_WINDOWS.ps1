$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

Write-Host "Grupo Idea Aberturas - compilacion APK" -ForegroundColor Cyan

$java = Get-Command java -ErrorAction SilentlyContinue
if (-not $java) {
    Write-Error "No se encontro Java. Instale Android Studio (incluye JDK) o JDK 17."
}

$gradle = Get-Command gradle -ErrorAction SilentlyContinue
if (-not $gradle) {
    Write-Host "No se encontro 'gradle' en PATH." -ForegroundColor Yellow
    Write-Host "Opcion recomendada: abra esta carpeta en Android Studio y use Build > Build APK(s)."
    Write-Host "Alternativa: instale Gradle 8.9 y vuelva a ejecutar este script."
    exit 2
}

& gradle :app:assembleDebug --stacktrace
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$apk = Join-Path (Get-Location) "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $apk) {
    Write-Host "APK generado:" -ForegroundColor Green
    Write-Host $apk
} else {
    Write-Error "Gradle termino sin error, pero no se encontro el APK esperado."
}
