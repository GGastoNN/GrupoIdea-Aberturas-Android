package com.grupoidea.aberturas;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT_GIC = 1001;
    private static final int REQ_EXPORT_GIP = 1002;
    private static final String CATALOG_CACHE = "catalogo_importado.gic";
    private static final String DRAFT_CACHE = "borrador_aberturas.json";

    private JSONObject catalogRoot;
    private final List<JSONObject> selectableSubtypes = new ArrayList<>();
    private final List<Opening> openings = new ArrayList<>();
    private final ProjectConfig projectConfig = new ProjectConfig();
    private String pendingExportJson;

    private TextView catalogStatus;
    private EditText projectName;
    private Spinner subtypeSpinner;
    private EditText openingName;
    private EditText widthMm;
    private EditText heightMm;
    private EditText quantity;
    private EditText frameWidthMm;
    private EditText frameDepthMm;
    private EditText leafSectionMm;
    private LinearLayout openingsContainer;
    private Button exportButton;
    private Button hingeLeftButton;
    private Button hingeRightButton;
    private Button inwardButton;
    private Button outwardButton;
    private DoorPreviewView previewView;
    private String draftProjectName = "Proyecto móvil";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Grupo Idea Aberturas");
        loadCachedCatalog();
        loadDraft();
        buildUi();
        refreshSubtypeSpinner();
        refreshOpenings();
        syncConfigToUi();
        refreshPreviewFromUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(244, 247, 250));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(headerCard());
        root.addView(actionMenu());
        root.addView(statusCard());
        root.addView(projectSection());
        root.addView(configSection());
        root.addView(newOpeningSection());
        root.addView(openingsSection());
        root.addView(exportSection());

        setContentView(scroll);
    }

    private View headerCard() {
        LinearLayout card = cardContainer();
        card.setBackground(roundedDrawable(Color.WHITE, dp(20), 0xFFE0E6EC, 1));

        TextView title = text("Grupo Idea · Aberturas de chapa", 24, true);
        title.setTextColor(Color.rgb(26, 41, 57));
        TextView subtitle = text("Configurador visual móvil · compatible con Cotizador Integral v5.5", 14, false);
        subtitle.setTextColor(Color.rgb(91, 108, 125));

        card.addView(title);
        card.addView(space(6));
        card.addView(subtitle);
        return card;
    }

    private View actionMenu() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(12), 0, dp(4));
        hsv.addView(row);

        row.addView(actionTile("Catálogo", "Importar .gic", android.R.drawable.ic_menu_upload, v -> chooseCatalog()));
        row.addView(actionTile("Proyecto", "Exportar .gip", android.R.drawable.ic_menu_save, v -> beginExport()));
        row.addView(actionTile("Abertura", "Agregar a lista", android.R.drawable.ic_input_add, v -> addOpening()));
        row.addView(actionTile("Vista", "Actualizar", android.R.drawable.ic_popup_sync, v -> refreshPreviewFromUi()));
        return hsv;
    }

    private View statusCard() {
        LinearLayout card = cardContainer();
        card.setBackground(roundedDrawable(0xFFF8FBFF, dp(18), 0xFFD6E5F3, 1));
        TextView t = section("Catálogo");
        catalogStatus = text("Catálogo: no cargado", 14, true);
        catalogStatus.setTextColor(Color.rgb(33, 87, 133));
        card.addView(t);
        card.addView(catalogStatus);
        return card;
    }

    private View projectSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Proyecto"));
        projectName = input("Nombre del proyecto", draftProjectName);
        projectName.addTextChangedListener(simpleWatcher());
        card.addView(projectName, fullWidth());
        return card;
    }

    private View configSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Configurador técnico"));
        card.addView(text("Ajustá el ancho de marco, espesor de marco y sección de hoja con controles visuales.", 13, false));

        previewView = new DoorPreviewView(this);
        LinearLayout previewCard = cardContainer();
        previewCard.setPadding(dp(12), dp(12), dp(12), dp(12));
        previewCard.setBackground(roundedDrawable(Color.WHITE, dp(18), 0xFFE3E8EE, 1));
        previewCard.addView(previewView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)));
        card.addView(space(10));
        card.addView(previewCard);

        card.addView(space(10));
        card.addView(parameterCard("Ancho de marco", "Sección marco", android.R.drawable.ic_menu_crop,
                frameWidthMm = numeric("125", "125"), -5, +5, 50, 500));
        card.addView(parameterCard("Espesor de marco", "Espesor lateral", android.R.drawable.ic_menu_manage,
                frameDepthMm = numeric("40", "40"), -2, +2, 20, 200));
        card.addView(parameterCard("Sección de hoja", "Sección hoja", android.R.drawable.ic_menu_edit,
                leafSectionMm = numeric("50", "50"), -2, +2, 20, 200));

        frameWidthMm.addTextChangedListener(simpleWatcher());
        frameDepthMm.addTextChangedListener(simpleWatcher());
        leafSectionMm.addTextChangedListener(simpleWatcher());

        card.addView(space(10));
        card.addView(sectionMini("Bisagras y apertura"));
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        hingeLeftButton = optionButton("Bisagra izq.", android.R.drawable.ic_media_previous, true, v -> {
            projectConfig.hingeLeft = true;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        hingeRightButton = optionButton("Bisagra der.", android.R.drawable.ic_media_next, false, v -> {
            projectConfig.hingeLeft = false;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        row1.addView(hingeLeftButton, weighted());
        row1.addView(hingeRightButton, weighted());
        card.addView(row1, fullWidth());

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        inwardButton = optionButton("Abre interior", android.R.drawable.ic_menu_revert, true, v -> {
            projectConfig.opensInward = true;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        outwardButton = optionButton("Abre exterior", android.R.drawable.ic_menu_share, false, v -> {
            projectConfig.opensInward = false;
            refreshOptionButtons();
            refreshPreviewFromUi();
        });
        row2.addView(inwardButton, weighted());
        row2.addView(outwardButton, weighted());
        card.addView(space(6));
        card.addView(row2, fullWidth());

        refreshOptionButtons();
        return card;
    }

    private View newOpeningSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Nueva abertura"));

        card.addView(label("Tipología de chapa"));
        subtypeSpinner = new Spinner(this);
        card.addView(subtypeSpinner, fullWidth());

        openingName = input("Identificación", "Abertura 1");
        openingName.addTextChangedListener(simpleWatcher());
        card.addView(space(8));
        card.addView(openingName, fullWidth());

        LinearLayout dims = new LinearLayout(this);
        dims.setOrientation(LinearLayout.HORIZONTAL);
        widthMm = numeric("900", "900");
        heightMm = numeric("2100", "2100");
        quantity = numeric("1", "1");
        widthMm.setHint("Ancho mm");
        heightMm.setHint("Alto mm");
        quantity.setHint("Cantidad");
        widthMm.addTextChangedListener(simpleWatcher());
        heightMm.addTextChangedListener(simpleWatcher());
        dims.addView(labeledField("Ancho", widthMm), weighted());
        dims.addView(labeledField("Alto", heightMm), weighted());
        dims.addView(labeledField("Cant.", quantity), weighted());
        card.addView(space(8));
        card.addView(dims, fullWidth());

        Button add = primaryButton("Agregar abertura", android.R.drawable.ic_input_add);
        add.setOnClickListener(v -> addOpening());
        card.addView(space(10));
        card.addView(add, fullWidth());
        return card;
    }

    private View openingsSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Aberturas del proyecto"));
        openingsContainer = new LinearLayout(this);
        openingsContainer.setOrientation(LinearLayout.VERTICAL);
        card.addView(openingsContainer, fullWidth());

        Button clear = secondaryButton("Vaciar lista", android.R.drawable.ic_menu_delete);
        clear.setOnClickListener(v -> {
            openings.clear();
            saveDraft();
            refreshOpenings();
        });
        card.addView(space(8));
        card.addView(clear, fullWidth());
        return card;
    }

    private View exportSection() {
        LinearLayout card = cardContainer();
        card.addView(section("Exportación"));
        exportButton = primaryButton("Exportar proyecto .gip", android.R.drawable.ic_menu_save);
        exportButton.setOnClickListener(v -> beginExport());
        card.addView(exportButton, fullWidth());
        card.addView(space(8));
        TextView note = text("Importante: la PC debe tener activo el mismo .gic importado en el teléfono para evitar diferencias de catálogo.", 12, false);
        note.setTextColor(Color.rgb(96, 108, 119));
        card.addView(note);
        return card;
    }

    private View actionTile(String title, String subtitle, int iconRes, View.OnClickListener onClick) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(14), dp(12), dp(14), dp(12));
        tile.setBackground(roundedDrawable(Color.WHITE, dp(18), 0xFFE0E6EC, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, dp(10), 0);
        tile.setLayoutParams(lp);
        tile.setClickable(true);
        tile.setOnClickListener(onClick);

        ImageView iv = new ImageView(this);
        iv.setImageResource(iconRes);
        iv.setColorFilter(Color.rgb(37, 114, 177));
        tile.addView(iv, new LinearLayout.LayoutParams(dp(28), dp(28)));
        tile.addView(space(6));
        TextView t1 = text(title, 15, true);
        TextView t2 = text(subtitle, 12, false);
        t2.setTextColor(Color.rgb(98, 111, 125));
        tile.addView(t1);
        tile.addView(t2);
        return tile;
    }

    private View parameterCard(String title, String subtitle, int iconRes, EditText field, int minusStep, int plusStep, int min, int max) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = fullWidth();
        lp.topMargin = dp(8);
        card.setLayoutParams(lp);
        card.setBackground(roundedDrawable(0xFFFDFEFE, dp(16), 0xFFE2E7EC, 1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setImageResource(iconRes);
        iv.setColorFilter(Color.rgb(42, 112, 169));
        header.addView(iv, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(10), 0, 0, 0);
        TextView t1 = text(title, 15, true);
        TextView t2 = text(subtitle, 12, false);
        t2.setTextColor(Color.rgb(105, 118, 132));
        texts.addView(t1);
        texts.addView(t2);
        header.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(header);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, 0);

        Button minus = miniStepButton(String.format(Locale.US, "%+d", minusStep));
        minus.setOnClickListener(v -> adjustField(field, minusStep, min, max));
        Button plus = miniStepButton(String.format(Locale.US, "%+d", plusStep));
        plus.setOnClickListener(v -> adjustField(field, plusStep, min, max));

        TextView unit = text("mm", 14, true);
        unit.setPadding(dp(10), 0, 0, 0);

        row.addView(minus, new LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        fp.setMargins(dp(8), 0, dp(8), 0);
        row.addView(field, fp);
        row.addView(plus, new LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(unit);
        card.addView(row);
        return card;
    }

    private View labeledField(String label, EditText field) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView l = text(label, 12, true);
        l.setPadding(dp(2), 0, 0, dp(4));
        box.addView(l);
        box.addView(field, fullWidth());
        return box;
    }

    private Button optionButton(String label, int iconRes, boolean active, View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(8));
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
        b.setOnClickListener(onClick);
        styleOptionButton(b, active);
        return b;
    }

    private void refreshOptionButtons() {
        if (hingeLeftButton != null) styleOptionButton(hingeLeftButton, projectConfig.hingeLeft);
        if (hingeRightButton != null) styleOptionButton(hingeRightButton, !projectConfig.hingeLeft);
        if (inwardButton != null) styleOptionButton(inwardButton, projectConfig.opensInward);
        if (outwardButton != null) styleOptionButton(outwardButton, !projectConfig.opensInward);
    }

    private void styleOptionButton(Button b, boolean active) {
        int bg = active ? 0xFFDCEEFE : 0xFFF3F6F9;
        int border = active ? 0xFF5AA7E6 : 0xFFD8E0E7;
        int fg = active ? Color.rgb(24, 92, 145) : Color.rgb(58, 74, 88);
        b.setBackground(roundedDrawable(bg, dp(16), border, 1));
        b.setTextColor(fg);
        for (Drawable d : b.getCompoundDrawables()) if (d != null) d.setTint(fg);
    }

    private Button primaryButton(String text, int iconRes) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(roundedDrawable(0xFF2E7BC6, dp(16), 0xFF2E7BC6, 1));
        b.setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(8));
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        return b;
    }

    private Button secondaryButton(String text, int iconRes) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setBackground(roundedDrawable(0xFFF3F6F9, dp(16), 0xFFD8E0E7, 1));
        b.setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(8));
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        return b;
    }

    private Button miniStepButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setBackground(roundedDrawable(0xFFF3F6F9, dp(14), 0xFFD9E1E7, 1));
        return b;
    }

    private void chooseCatalog() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/octet-stream", "text/plain"});
        startActivityForResult(i, REQ_IMPORT_GIC);
    }

    private void addOpening() {
        if (catalogRoot == null || selectableSubtypes.isEmpty()) {
            toast("Primero importá el catálogo .gic del Cotizador.");
            return;
        }
        syncConfigFromUi();
        int w = parsePositive(widthMm, "ancho");
        int h = parsePositive(heightMm, "alto");
        int q = parsePositive(quantity, "cantidad");
        if (w <= 0 || h <= 0 || q <= 0) return;

        int pos = subtypeSpinner.getSelectedItemPosition();
        if (pos < 0 || pos >= selectableSubtypes.size()) {
            toast("Elegí una tipología.");
            return;
        }
        JSONObject st = selectableSubtypes.get(pos);
        Opening op = new Opening();
        op.id = "mob-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        op.name = openingName.getText().toString().trim();
        if (op.name.isEmpty()) op.name = "Abertura " + (openings.size() + 1);
        op.widthMm = w;
        op.heightMm = h;
        op.quantity = q;
        op.subtypeId = st.optString("Id", "");
        op.subtypeName = st.optString("Nombre", "Tipología");
        op.type = st.optInt("Tipo", 0);
        openings.add(op);
        openingName.setText("Abertura " + (openings.size() + 1));
        saveDraft();
        refreshOpenings();
        toast("Abertura agregada al proyecto.");
    }

    private void beginExport() {
        if (catalogRoot == null) {
            toast("Importá primero el catálogo .gic.");
            return;
        }
        if (openings.isEmpty()) {
            toast("Agregá al menos una abertura.");
            return;
        }
        syncConfigFromUi();
        try {
            JSONObject gip = GipProjectBuilder.build(projectName.getText().toString(), catalogRoot, projectConfig, openings);
            pendingExportJson = gip.toString();
        } catch (JSONException ex) {
            toast("No se pudo generar el proyecto: " + ex.getMessage());
            return;
        }

        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, safeName(projectName.getText().toString()) + ".gip");
        startActivityForResult(i, REQ_EXPORT_GIP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_IMPORT_GIC) {
            importCatalog(uri);
        } else if (requestCode == REQ_EXPORT_GIP) {
            exportProject(uri);
        }
    }

    private void importCatalog(Uri uri) {
        try {
            String json = readAll(getContentResolver().openInputStream(uri));
            JSONObject root = new JSONObject(json);
            if (!"GRUPO_IDEA_CATALOG_GIC".equalsIgnoreCase(root.optString("Formato", ""))) {
                toast("El archivo no es un catálogo .gic válido de Grupo Idea.");
                return;
            }
            JSONArray types = root.optJSONArray("Tipologias");
            if (types == null || types.length() == 0) {
                toast("El catálogo no contiene tipologías.");
                return;
            }
            catalogRoot = root;
            applyCatalogDefaults(root.optJSONObject("Settings"));
            cacheCatalog(json);
            refreshSubtypeSpinner();
            updateCatalogStatus();
            refreshPreviewFromUi();
            toast("Catálogo importado correctamente.");
        } catch (Exception ex) {
            toast("No se pudo leer el .gic: " + ex.getMessage());
        }
    }

    private void exportProject(Uri uri) {
        if (pendingExportJson == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri, "w");
             OutputStreamWriter writer = new OutputStreamWriter(os, StandardCharsets.UTF_8)) {
            writer.write(pendingExportJson);
            writer.flush();
            toast("Proyecto .gip generado. Ya podés abrirlo en el Cotizador de PC.");
        } catch (Exception ex) {
            toast("No se pudo guardar el .gip: " + ex.getMessage());
        } finally {
            pendingExportJson = null;
        }
    }

    private void refreshSubtypeSpinner() {
        selectableSubtypes.clear();
        List<String> labels = new ArrayList<>();
        if (catalogRoot != null) {
            JSONArray all = catalogRoot.optJSONArray("Tipologias");
            List<JSONObject> fallback = new ArrayList<>();
            if (all != null) {
                for (int i = 0; i < all.length(); i++) {
                    JSONObject st = all.optJSONObject(i);
                    if (st == null) continue;
                    fallback.add(st);
                    if (hasConformedSheet(st)) selectableSubtypes.add(st);
                }
            }
            if (selectableSubtypes.isEmpty()) selectableSubtypes.addAll(fallback);
        }
        for (JSONObject st : selectableSubtypes) {
            labels.add(st.optString("Nombre", st.optString("Id", "Tipología")));
        }
        if (labels.isEmpty()) labels.add("Importá un catálogo .gic");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subtypeSpinner.setAdapter(adapter);
        updateCatalogStatus();
    }

    private boolean hasConformedSheet(JSONObject subtype) {
        JSONArray parts = subtype.optJSONArray("Partes");
        if (parts == null) return false;
        for (int i = 0; i < parts.length(); i++) {
            JSONObject p = parts.optJSONObject(i);
            if (p != null && p.optInt("Geometria", 0) == 2) return true;
        }
        return false;
    }

    private void updateCatalogStatus() {
        if (catalogStatus == null) return;
        if (catalogRoot == null) {
            catalogStatus.setText("Catálogo: no cargado");
            return;
        }
        String hash = catalogRoot.optString("Hash", "");
        if (hash.length() > 12) hash = hash.substring(0, 12) + "…";
        catalogStatus.setText("Catálogo cargado · " + selectableSubtypes.size() + " tipologías de chapa · hash " + hash);
    }

    private void refreshOpenings() {
        if (openingsContainer == null) return;
        openingsContainer.removeAllViews();
        if (openings.isEmpty()) {
            TextView none = text("Todavía no hay aberturas cargadas.", 13, false);
            none.setPadding(0, dp(8), 0, dp(10));
            openingsContainer.addView(none);
            return;
        }
        for (int i = 0; i < openings.size(); i++) {
            final int index = i;
            Opening op = openings.get(i);
            LinearLayout row = cardContainer();
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(roundedDrawable(Color.WHITE, dp(16), 0xFFE2E8EE, 1));

            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            ImageView icon = new ImageView(this);
            icon.setImageResource(android.R.drawable.ic_menu_agenda);
            icon.setColorFilter(Color.rgb(39, 112, 171));
            top.addView(icon, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView info = text(op.name + " · " + op.widthMm + "×" + op.heightMm + " mm · x" + op.quantity, 14, true);
            info.setPadding(dp(8), 0, 0, 0);
            top.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(top);
            TextView sub = text(op.subtypeName, 13, false);
            sub.setTextColor(Color.rgb(95, 108, 122));
            sub.setPadding(0, dp(6), 0, dp(8));
            row.addView(sub);
            Button del = secondaryButton("Eliminar", android.R.drawable.ic_menu_delete);
            del.setOnClickListener(v -> {
                openings.remove(index);
                saveDraft();
                refreshOpenings();
            });
            row.addView(del, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            openingsContainer.addView(row, fullWidth());
        }
    }

    private void adjustField(EditText field, int delta, int min, int max) {
        int cur = parseOr(field, min);
        cur += delta;
        if (cur < min) cur = min;
        if (cur > max) cur = max;
        field.setText(String.valueOf(cur));
        field.setSelection(field.getText().length());
        syncConfigFromUi();
        refreshPreviewFromUi();
    }

    private void applyCatalogDefaults(JSONObject s) {
        if (s == null) return;
        if (frameWidthMm == null || frameWidthMm.getText().toString().trim().isEmpty()) {
            projectConfig.frameWidthMm = (int) Math.round(s.optDouble("SeccionMarcoMM", projectConfig.frameWidthMm));
        }
        if (frameDepthMm == null || frameDepthMm.getText().toString().trim().isEmpty()) {
            projectConfig.frameDepthMm = (int) Math.round(s.optDouble("EspesorLateralMarcoMM", projectConfig.frameDepthMm));
        }
        if (leafSectionMm == null || leafSectionMm.getText().toString().trim().isEmpty()) {
            projectConfig.leafSectionMm = (int) Math.round(s.optDouble("SeccionHojaMM", projectConfig.leafSectionMm));
        }
        projectConfig.frameWidthMm = (int) Math.round(s.optDouble("SeccionMarcoMM", projectConfig.frameWidthMm));
        projectConfig.frameDepthMm = (int) Math.round(s.optDouble("EspesorLateralMarcoMM", projectConfig.frameDepthMm));
        projectConfig.leafSectionMm = (int) Math.round(s.optDouble("SeccionHojaMM", projectConfig.leafSectionMm));
        syncConfigToUi();
    }

    private void syncConfigToUi() {
        if (frameWidthMm != null) frameWidthMm.setText(String.valueOf(projectConfig.frameWidthMm));
        if (frameDepthMm != null) frameDepthMm.setText(String.valueOf(projectConfig.frameDepthMm));
        if (leafSectionMm != null) leafSectionMm.setText(String.valueOf(projectConfig.leafSectionMm));
        refreshOptionButtons();
    }

    private void syncConfigFromUi() {
        projectConfig.frameWidthMm = clamp(parseOr(frameWidthMm, projectConfig.frameWidthMm), 50, 500);
        projectConfig.frameDepthMm = clamp(parseOr(frameDepthMm, projectConfig.frameDepthMm), 20, 200);
        projectConfig.leafSectionMm = clamp(parseOr(leafSectionMm, projectConfig.leafSectionMm), 20, 200);
    }

    private void refreshPreviewFromUi() {
        syncConfigFromUi();
        if (previewView != null) {
            int w = clamp(parseOr(widthMm, 900), 300, 3000);
            int h = clamp(parseOr(heightMm, 2100), 600, 4000);
            previewView.setModel(w, h, projectConfig);
        }
        saveDraft();
    }

    private void cacheCatalog(String json) {
        try (FileOutputStream fos = openFileOutput(CATALOG_CACHE, MODE_PRIVATE)) {
            fos.write(json.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    private void loadCachedCatalog() {
        try (FileInputStream fis = openFileInput(CATALOG_CACHE)) {
            String json = readAll(fis);
            JSONObject root = new JSONObject(json);
            if ("GRUPO_IDEA_CATALOG_GIC".equalsIgnoreCase(root.optString("Formato", ""))) {
                catalogRoot = root;
                applyCatalogDefaults(root.optJSONObject("Settings"));
            }
        } catch (Exception ignored) { }
    }

    private void saveDraft() {
        try {
            JSONObject root = new JSONObject();
            root.put("projectName", projectName != null ? projectName.getText().toString() : "Proyecto móvil");
            root.put("config", projectConfig.toJson());
            JSONArray arr = new JSONArray();
            for (Opening op : openings) arr.put(op.toJson());
            root.put("openings", arr);
            try (FileOutputStream fos = openFileOutput(DRAFT_CACHE, MODE_PRIVATE)) {
                fos.write(root.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { }
    }

    private void loadDraft() {
        try (FileInputStream fis = openFileInput(DRAFT_CACHE)) {
            String raw = readAll(fis);
            openings.clear();
            if (raw.trim().startsWith("[")) {
                JSONArray arr = new JSONArray(raw);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o != null) openings.add(Opening.fromJson(o));
                }
                return;
            }
            JSONObject root = new JSONObject(raw);
            projectConfig.copyFrom(ProjectConfig.fromJson(root.optJSONObject("config")));
            JSONArray arr = root.optJSONArray("openings");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o != null) openings.add(Opening.fromJson(o));
                }
            }
            draftProjectName = root.optString("projectName", "Proyecto móvil");
            if (projectName != null) projectName.setText(draftProjectName);
        } catch (Exception ignored) { }
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) throw new IllegalStateException("No se pudo abrir el archivo.");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) >= 0) sb.append(buf, 0, n);
        }
        return sb.toString();
    }

    private int parsePositive(EditText e, String field) {
        try {
            int v = Integer.parseInt(e.getText().toString().trim());
            if (v <= 0) throw new NumberFormatException();
            return v;
        } catch (Exception ex) {
            toast("Ingresá un valor válido para " + field + ".");
            e.requestFocus();
            return -1;
        }
    }

    private int parseOr(EditText e, int fallback) {
        if (e == null) return fallback;
        try { return Integer.parseInt(e.getText().toString().trim()); }
        catch (Exception ex) { return fallback; }
    }

    private int clamp(int x, int min, int max) {
        return Math.max(min, Math.min(max, x));
    }

    private TextWatcher simpleWatcher() {
        return new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) { refreshPreviewFromUi(); }
        };
    }

    private TextView section(String s) {
        TextView t = text(s, 18, true);
        t.setPadding(0, 0, 0, dp(8));
        return t;
    }

    private TextView sectionMini(String s) {
        TextView t = text(s, 14, true);
        t.setPadding(0, dp(2), 0, dp(8));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, true);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(28, 37, 48));
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private EditText input(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setText(value);
        e.setPadding(dp(12), dp(12), dp(12), dp(12));
        e.setBackground(roundedDrawable(Color.WHITE, dp(14), 0xFFD8E0E7, 1));
        return e;
    }

    private EditText numeric(String hint, String value) {
        EditText e = input(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSelectAllOnFocus(true);
        e.setGravity(Gravity.CENTER_HORIZONTAL);
        return e;
    }

    private LinearLayout cardContainer() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = fullWidth();
        lp.topMargin = dp(12);
        card.setLayoutParams(lp);
        card.setBackground(roundedDrawable(Color.WHITE, dp(18), 0xFFE2E8EE, 1));
        return card;
    }

    private GradientDrawable roundedDrawable(int bg, int radius, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg);
        d.setCornerRadius(radius);
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private View space(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(dp)));
        return v;
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private String safeName(String s) {
        if (s == null || s.trim().isEmpty()) return "Proyecto_movil";
        return s.trim().replaceAll("[^a-zA-Z0-9._-]+", "_");
    }
}
