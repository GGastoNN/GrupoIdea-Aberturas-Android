package com.grupoidea.aberturas;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

final class GipProjectBuilder {
    static final String GIP_FORMAT = "GRUPO_IDEA_PROJECT_GIP";
    static final int GIP_SCHEMA = 6;
    static final int CATALOG_VERSION_FOR_GIP = 3;

    private GipProjectBuilder() {}

    static JSONObject build(String projectName, JSONObject gic, ProjectConfig config, List<Opening> openings) throws JSONException {
        String uid = shortUid();
        JSONObject out = new JSONObject();
        out.put("Formato", GIP_FORMAT);
        out.put("VersionEsquema", GIP_SCHEMA);
        out.put("Software", "Grupo Idea Aberturas Android 1.1.0");
        out.put("GeneradoUtc", Instant.now().toString());
        out.put("Nombre", emptyTo(projectName, "Proyecto móvil"));

        JSONArray tipos = new JSONArray();
        for (int i = 0; i < openings.size(); i++) {
            Opening op = openings.get(i);
            JSONObject t = new JSONObject();
            t.put("Accesorios", new JSONArray());
            t.put("Id", emptyTo(op.id, "mob-" + shortUid()));
            t.put("Tipo", op.type);
            t.put("SubtipoId", op.subtypeId);
            t.put("AnchoMM", op.widthMm);
            t.put("AltoMM", op.heightMm);
            t.put("X", 20.0 + (i % 3) * 240.0);
            t.put("Y", 20.0 + (i / 3) * 200.0);
            t.put("InstanceName", emptyTo(op.name, "Abertura " + (i + 1)));
            t.put("ColorArgb", -1);
            t.put("Locked", false);
            t.put("Cantidad", Math.max(1, op.quantity));
            t.put("Tubos", new JSONArray());
            t.put("Interiores", new JSONArray());
            t.put("HorasFabrica", new JSONArray());
            t.put("ItemManual", new JSONArray());
            t.put("AjustesEnsamblaje", new JSONArray());
            tipos.put(t);
        }
        out.put("Tipos", tipos);
        out.put("Accesorios", new JSONArray());
        out.put("ItemsManuales", new JSONArray());
        out.put("Settings", settingsSnapshot(gic.optJSONObject("Settings"), config, uid));
        out.put("CatalogHash", gic.optString("Hash", ""));
        out.put("CatalogVersion", CATALOG_VERSION_FOR_GIP);
        out.put("Cantidad", 1);
        out.put("Uid", uid);
        return out;
    }

    private static JSONObject settingsSnapshot(JSONObject s, ProjectConfig config, String uid) throws JSONException {
        if (s == null) s = new JSONObject();
        if (config == null) config = new ProjectConfig();
        JSONObject o = new JSONObject();
        o.put("SeccionMarcoMM", config.frameWidthMm);
        o.put("SeccionHojaMM", config.leafSectionMm);
        o.put("CalibreMarco", s.optInt("CalibreMarco", 18));
        o.put("CalibreHoja", s.optInt("CalibreHoja", 18));
        o.put("LaminadoCaliente", s.optBoolean("LaminadoCaliente", false));
        o.put("EspesorLateralMarcoMM", config.frameDepthMm);
        o.put("PrecioChapaPorKg", s.optDouble("PrecioChapaPorKg", 0.0));
        o.put("PlanchaAnchoMM", s.optInt("PlanchaAnchoMM", 1500));
        o.put("PlanchaLargoMM", s.optInt("PlanchaLargoMM", 3000));
        o.put("KerfMM", s.optDouble("KerfMM", 0.0));
        o.put("PermitirRotacion", s.optBoolean("PermitirRotacion", true));
        o.put("ModoDesarrollo", s.optInt("ModoDesarrollo", 0));
        o.put("KFactorMarco", s.optDouble("KFactorMarco", 0.42));
        o.put("KFactorHoja", s.optDouble("KFactorHoja", 0.42));
        o.put("RadioInteriorMarcoMM", s.optDouble("RadioInteriorMarcoMM", 1.5));
        o.put("RadioInteriorHojaMM", s.optDouble("RadioInteriorHojaMM", 1.5));
        o.put("ToleranciaLargoMM", s.optDouble("ToleranciaLargoMM", 1.0));
        o.put("ToleranciaDesarrolloMM", s.optDouble("ToleranciaDesarrolloMM", 0.5));
        o.put("Uid", uid);
        return o;
    }

    private static String shortUid() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 8).toLowerCase(Locale.US);
    }

    private static String emptyTo(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }
}
