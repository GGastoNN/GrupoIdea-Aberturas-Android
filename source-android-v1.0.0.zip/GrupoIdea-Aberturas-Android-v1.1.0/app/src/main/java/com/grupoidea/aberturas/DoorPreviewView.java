package com.grupoidea.aberturas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class DoorPreviewView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint accent = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int openingWidthMm = 900;
    private int openingHeightMm = 2100;
    private ProjectConfig config = new ProjectConfig();

    public DoorPreviewView(Context context) {
        super(context);
        init();
    }

    public DoorPreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2f));
        stroke.setColor(Color.rgb(47, 79, 79));
        text.setColor(Color.rgb(37, 48, 61));
        text.setTextSize(dp(12f));
        accent.setStyle(Paint.Style.STROKE);
        accent.setStrokeWidth(dp(2.5f));
        accent.setColor(Color.rgb(40, 121, 187));
    }

    public void setModel(int openingWidthMm, int openingHeightMm, ProjectConfig config) {
        this.openingWidthMm = Math.max(100, openingWidthMm);
        this.openingHeightMm = Math.max(100, openingHeightMm);
        if (config != null) this.config = config;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int desired = (int) dp(220f);
        int w = resolveSize(desired, widthMeasureSpec);
        int h = resolveSize((int) dp(260f), heightMeasureSpec);
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth();
        float h = getHeight();
        c.drawColor(Color.WHITE);

        float pad = dp(16f);
        float top = dp(28f);
        float availW = w - pad * 2;
        float availH = h - top - pad;
        float ratio = Math.min(availW / openingWidthMm, availH / openingHeightMm);
        float frameW = openingWidthMm * ratio;
        float frameH = openingHeightMm * ratio;
        float left = (w - frameW) / 2f;
        float right = left + frameW;
        float bottom = top + frameH;

        // Opening background
        fill.setColor(Color.rgb(248, 250, 252));
        c.drawRect(left, top, right, bottom, fill);

        // Frame section represented by project frame width (scaled to visible view, clamped)
        float sec = clamp(config.frameWidthMm * ratio, dp(10f), frameW * 0.18f);
        fill.setColor(Color.rgb(95, 117, 136));
        c.drawRect(left, top, right, top + sec, fill);
        c.drawRect(left, bottom - sec, right, bottom, fill);
        c.drawRect(left, top, left + sec, bottom, fill);
        c.drawRect(right - sec, top, right, bottom, fill);

        // Leaf
        float gap = dp(6f);
        float leafLeft = left + sec + gap;
        float leafTop = top + sec + gap;
        float leafRight = right - sec - gap;
        float leafBottom = bottom - sec - gap;
        fill.setColor(Color.rgb(222, 230, 236));
        c.drawRect(leafLeft, leafTop, leafRight, leafBottom, fill);
        stroke.setColor(Color.rgb(52, 73, 94));
        c.drawRect(leafLeft, leafTop, leafRight, leafBottom, stroke);

        // Leaf section lip / stop
        float leafSec = clamp(config.leafSectionMm * ratio * 0.45f, dp(4f), frameW * 0.08f);
        float stopX = config.hingeLeft ? leafLeft + leafSec : leafRight - leafSec;
        fill.setColor(Color.rgb(188, 204, 216));
        if (config.hingeLeft) c.drawRect(leafLeft, leafTop, stopX, leafBottom, fill);
        else c.drawRect(stopX, leafTop, leafRight, leafBottom, fill);

        // Hinges
        float hingeX = config.hingeLeft ? leafLeft - dp(4f) : leafRight + dp(4f);
        fill.setColor(Color.rgb(214, 155, 44));
        for (int i = 0; i < 3; i++) {
            float yy = leafTop + (leafBottom - leafTop) * (0.18f + i * 0.31f);
            c.drawRoundRect(hingeX - dp(4f), yy - dp(8f), hingeX + dp(4f), yy + dp(8f), dp(3f), dp(3f), fill);
        }

        // Swing arc and arrow
        Path p = new Path();
        float pivotX = config.hingeLeft ? leafLeft : leafRight;
        float pivotY = (leafTop + leafBottom) / 2f;
        float arcR = Math.min(frameW, frameH) * 0.28f;
        float startAngle = config.hingeLeft ? -40f : 220f;
        float sweep = config.opensInward ? 55f : -55f;
        android.graphics.RectF arc = new android.graphics.RectF(pivotX - arcR, pivotY - arcR, pivotX + arcR, pivotY + arcR);
        p.addArc(arc, startAngle, sweep);
        c.drawPath(p, accent);
        float endAng = (float) Math.toRadians(startAngle + sweep);
        float endX = pivotX + (float) Math.cos(endAng) * arcR;
        float endY = pivotY + (float) Math.sin(endAng) * arcR;
        drawArrowHead(c, endX, endY, endAng + (sweep >= 0 ? 1f : -1f) * 0.15f);

        // Labels
        c.drawText(openingWidthMm + " × " + openingHeightMm + " mm", left, dp(16f), text);
        c.drawText("Marco " + config.frameWidthMm + " / Espesor " + config.frameDepthMm + " / Hoja " + config.leafSectionMm + " mm", left, bottom + dp(18f), text);
        c.drawText(config.hingeLeft ? "Bisagra izquierda" : "Bisagra derecha", left, bottom + dp(34f), text);
    }

    private void drawArrowHead(Canvas c, float x, float y, float angleRad) {
        float len = dp(8f);
        float a1 = angleRad + (float) Math.toRadians(150);
        float a2 = angleRad - (float) Math.toRadians(150);
        c.drawLine(x, y, x + (float) Math.cos(a1) * len, y + (float) Math.sin(a1) * len, accent);
        c.drawLine(x, y, x + (float) Math.cos(a2) * len, y + (float) Math.sin(a2) * len, accent);
    }

    private float clamp(float x, float min, float max) {
        return Math.max(min, Math.min(max, x));
    }

    private float dp(float n) {
        return n * getResources().getDisplayMetrics().density;
    }
}
