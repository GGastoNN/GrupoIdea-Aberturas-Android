package com.grupoidea.aberturas;

import org.json.JSONException;
import org.json.JSONObject;

final class Opening {
    String id;
    String name;
    int widthMm;
    int heightMm;
    int quantity;
    String subtypeId;
    String subtypeName;
    int type;

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("widthMm", widthMm);
        o.put("heightMm", heightMm);
        o.put("quantity", quantity);
        o.put("subtypeId", subtypeId);
        o.put("subtypeName", subtypeName);
        o.put("type", type);
        return o;
    }

    static Opening fromJson(JSONObject o) {
        Opening x = new Opening();
        x.id = o.optString("id", "");
        x.name = o.optString("name", "Abertura");
        x.widthMm = o.optInt("widthMm", 900);
        x.heightMm = o.optInt("heightMm", 2100);
        x.quantity = Math.max(1, o.optInt("quantity", 1));
        x.subtypeId = o.optString("subtypeId", "");
        x.subtypeName = o.optString("subtypeName", "");
        x.type = o.optInt("type", 0);
        return x;
    }
}
