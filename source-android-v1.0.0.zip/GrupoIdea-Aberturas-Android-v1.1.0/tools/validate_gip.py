#!/usr/bin/env python3
"""Validador estructural mínimo del .gip generado por la app Android."""
import json, sys
p=sys.argv[1]
with open(p,'r',encoding='utf-8-sig') as f: d=json.load(f)
errors=[]
if d.get('Formato')!='GRUPO_IDEA_PROJECT_GIP': errors.append('Formato inválido')
if d.get('VersionEsquema')!=6: errors.append('VersionEsquema debe ser 6')
if not isinstance(d.get('Tipos'),list) or not d['Tipos']: errors.append('Tipos vacío')
if not isinstance(d.get('Settings'),dict): errors.append('Settings faltante')
for i,t in enumerate(d.get('Tipos',[]),1):
    for k in ('Id','SubtipoId','AnchoMM','AltoMM','Cantidad','Tipo'):
        if k not in t: errors.append(f'Tipo {i}: falta {k}')
    if int(t.get('AnchoMM',0))<=0 or int(t.get('AltoMM',0))<=0: errors.append(f'Tipo {i}: dimensiones inválidas')
if errors:
    print('NO VÁLIDO')
    for e in errors: print('-',e)
    sys.exit(1)
print('OK - GIP esquema 6 estructuralmente compatible')
print('Proyecto:',d.get('Nombre'))
print('Aberturas:',len(d['Tipos']))
print('CatalogHash:',d.get('CatalogHash',''))
