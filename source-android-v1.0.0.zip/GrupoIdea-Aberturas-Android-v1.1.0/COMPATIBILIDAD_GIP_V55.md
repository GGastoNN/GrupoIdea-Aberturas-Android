# Contrato de interoperabilidad Android ↔ Escritorio v5.5

## GIC leído por Android

- Formato: `GRUPO_IDEA_CATALOG_GIC`
- Hash: propiedad `Hash` del catálogo exportado por escritorio
- Tipologías: `Tipologias[]`
- Identificador estable: `Tipologias[].Id`
- Tipo principal: `Tipologias[].Tipo`
- Chapa conformada: una `Parte` con `Geometria = 2`
- Configuración: `Settings`

## GIP escrito por Android

- Formato: `GRUPO_IDEA_PROJECT_GIP`
- VersionEsquema: `6`
- CatalogVersion: `3`
- CatalogHash: copia del `Hash` del GIC
- Cada abertura se serializa como un `TipologiaDTO`
- `SubtipoId` conserva el ID exacto del catálogo
- `AnchoMM`, `AltoMM`, `Cantidad` provienen de la medición móvil
- Listas opcionales se serializan vacías para que el escritorio pueda completar accesorios, interiores, horas, tubos y ajustes 3D después.

## Qué se calcula en PC

El Android no duplica el motor de fabricación. Al abrir el GIP, el escritorio usa su catálogo y motor para resolver:

- marco y hoja;
- chapa conformada;
- desarrollo/K-Factor;
- travesaños;
- despuntes;
- bisagras;
- visor y ensamblaje 3D;
- nesting y DXF.

Esto evita divergencias numéricas entre el teléfono y la versión de fabricación.
