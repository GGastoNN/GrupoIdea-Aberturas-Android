# Compilar APK

Este proyecto puede compilarse con:

- **Android Studio**
- **GitHub Actions** (workflow incluido)

## Salida esperada

APK de depuración:

`app/build/outputs/apk/debug/app-debug.apk`

## Notas

- `versionName`: **1.1.0**
- `compileSdk`: **35**
- `targetSdk`: **35**
- `minSdk`: **26**
