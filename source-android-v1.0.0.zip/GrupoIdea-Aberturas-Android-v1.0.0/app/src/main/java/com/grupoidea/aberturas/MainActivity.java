package com.grupoidea.aberturas;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT_GIC = 1001;
    private static final int REQ_EXPORT_GIP = 1002;
    private static final String CATALOG_CACHE = "catalogo_importado.gic";
    private static final String DRAFT_CACHE = "borrador_aberturas.json";

    private JSONObject catalogRoot;
    private final List<JSONObject> selectableSubtypes = new ArrayList<>();
    private final List<Opening> openings = new ArrayList<>();
    private String pendingExportJson;

    private TextView catalogStatus;
    private EditText projectName;
    private Spinner subtypeSpinner;
    private EditText openingName;
    private EditText widthMm;
    private EditText heightMm;
    private EditText quantity;
    private LinearLayout openingsContainer;
    private Button exportButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Grupo Idea Aberturas");
        buildUi();
        loadCachedCatalog();
        loadDraft();
        refreshSubtypeSpinner();
        refreshOpenings();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Grupo Idea · Aberturas de chapa", 24, true);
        root.addView(title);
        root.addView(text("Crea aberturas en obra y exporta un .gip compatible con Cotizador Integral v5.5.", 14, false));

        Button importCatalog = button("Importar catálogo .gic");
        importCatalog.setOnClickListener(v -> chooseCatalog());
        root.addView(importCatalog, fullWidth());

        catalogStatus = text("Catálogo: no cargado", 14, true);
        catalogStatus.setPadding(0, dp(8), 0, dp(14));
        root.addView(catalogStatus);

        root.addView(section("Proyecto"));
        projectName = input("Nombre del proyecto", "Proyecto móvil");
        root.addView(projectName, fullWidth());

        root.addView(section("Nueva abertura"));
        root.addView(label("Tipología de chapa"));
        subtypeSpinner = new Spinner(this);
        root.addView(subtypeSpinner, fullWidth());

        openingName = input("Identificación", "Abertura 1");
        root.addView(openingName, fullWidth());

        LinearLayout dims = new LinearLayout(this);
        dims.setOrientation(LinearLayout.HORIZONTAL);
        widthMm = numeric("Ancho mm", "900");
        heightMm = numeric("Alto mm", "2100");
        quantity = numeric("Cantidad", "1");
        dims.addView(widthMm, weighted());
        dims.addView(heightMm, weighted());
        dims.addView(quantity, weighted());
        root.addView(dims, fullWidth());

        Button add = button("Agregar abertura");
        add.setOnClickListener(v -> addOpening());
        root.addView(add, fullWidth());

        root.addView(section("Aberturas del proyecto"));
        openingsContainer = new LinearLayout(this);
        openingsContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(openingsContainer, fullWidth());

        Button clear = button("Vaciar lista");
        clear.setOnClickListener(v -> {
            openings.clear();
            saveDraft();
            refreshOpenings();
        });
        root.addView(clear, fullWidth());

        exportButton = button("Exportar proyecto .gip");
        exportButton.setOnClickListener(v -> beginExport());
        root.addView(exportButton, fullWidth());

        TextView note = text("Importante: para evitar el aviso de catálogo diferente, la PC debe tener activo el mismo .gic que se importó en el teléfono.", 12, false);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void chooseCatalog() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/octet-stream", "text/plain"});
        startActivityForResult(i, REQ_IMPORT_GIC);
    }

    private void addOpening() {
        if (catalogRoot == null || selectableSubtypes.isEmpty()) {
            toast("Primero importá el catálogo .gic del Cotizador.");
            return;
        }
        int w = parsePositive(widthMm, "ancho");
        int h = parsePositive(heightMm, "alto");
        int q = parsePositive(quantity, "cantidad");
        if (w <= 0 || h <= 0 || q <= 0) return;

        int pos = subtypeSpinner.getSelectedItemPosition();
        if (pos < 0 || pos >= selectableSubtypes.size()) {
            toast("Elegí una tipología.");
            return;
        }
        JSONObject st = selectableSubtypes.get(pos);
        Opening op = new Opening();
        op.id = "mob-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        op.name = openingName.getText().toString().trim();
        if (op.name.isEmpty()) op.name = "Abertura " + (openings.size() + 1);
        op.widthMm = w;
        op.heightMm = h;
        op.quantity = q;
        op.subtypeId = st.optString("Id", "");
        op.subtypeName = st.optString("Nombre", "Tipología");
        op.type = st.optInt("Tipo", 0);
        openings.add(op);
        openingName.setText("Abertura " + (openings.size() + 1));
        saveDraft();
        refreshOpenings();
    }

    private void beginExport() {
        if (catalogRoot == null) {
            toast("Importá primero el catálogo .gic.");
            return;
        }
        if (openings.isEmpty()) {
            toast("Agregá al menos una abertura.");
            return;
        }
        try {
            JSONObject gip = GipProjectBuilder.build(projectName.getText().toString(), catalogRoot, openings);
            pendingExportJson = gip.toString();
        } catch (JSONException ex) {
            toast("No se pudo generar el proyecto: " + ex.getMessage());
            return;
        }

        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, safeName(projectName.getText().toString()) + ".gip");
        startActivityForResult(i, REQ_EXPORT_GIP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_IMPORT_GIC) {
            importCatalog(uri);
        } else if (requestCode == REQ_EXPORT_GIP) {
            exportProject(uri);
        }
    }

    private void importCatalog(Uri uri) {
        try {
            String json = readAll(getContentResolver().openInputStream(uri));
            JSONObject root = new JSONObject(json);
            if (!"GRUPO_IDEA_CATALOG_GIC".equalsIgnoreCase(root.optString("Formato", ""))) {
                toast("El archivo no es un catálogo .gic válido de Grupo Idea.");
                return;
            }
            JSONArray types = root.optJSONArray("Tipologias");
            if (types == null || types.length() == 0) {
                toast("El catálogo no contiene tipologías.");
                return;
            }
            catalogRoot = root;
            cacheCatalog(json);
            refreshSubtypeSpinner();
            updateCatalogStatus();
            toast("Catálogo importado correctamente.");
        } catch (Exception ex) {
            toast("No se pudo leer el .gic: " + ex.getMessage());
        }
    }

    private void exportProject(Uri uri) {
        if (pendingExportJson == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri, "w");
             OutputStreamWriter writer = new OutputStreamWriter(os, StandardCharsets.UTF_8)) {
            writer.write(pendingExportJson);
            writer.flush();
            toast("Proyecto .gip generado. Ya podés abrirlo en el Cotizador de PC.");
        } catch (Exception ex) {
            toast("No se pudo guardar el .gip: " + ex.getMessage());
        } finally {
            pendingExportJson = null;
        }
    }

    private void refreshSubtypeSpinner() {
        selectableSubtypes.clear();
        List<String> labels = new ArrayList<>();
        if (catalogRoot != null) {
            JSONArray all = catalogRoot.optJSONArray("Tipologias");
            List<JSONObject> fallback = new ArrayList<>();
            if (all != null) {
                for (int i = 0; i < all.length(); i++) {
                    JSONObject st = all.optJSONObject(i);
                    if (st == null) continue;
                    fallback.add(st);
                    if (hasConformedSheet(st)) selectableSubtypes.add(st);
                }
            }
            // Compatibilidad con catálogos antiguos: si no hay geometría marcada,
            // no bloqueamos al usuario y mostramos todas las tipologías.
            if (selectableSubtypes.isEmpty()) selectableSubtypes.addAll(fallback);
        }
        for (JSONObject st : selectableSubtypes) {
            labels.add(st.optString("Nombre", st.optString("Id", "Tipología")));
        }
        if (labels.isEmpty()) labels.add("Importá un catálogo .gic");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subtypeSpinner.setAdapter(adapter);
        updateCatalogStatus();
    }

    private boolean hasConformedSheet(JSONObject subtype) {
        JSONArray parts = subtype.optJSONArray("Partes");
        if (parts == null) return false;
        for (int i = 0; i < parts.length(); i++) {
            JSONObject p = parts.optJSONObject(i);
            if (p != null && p.optInt("Geometria", 0) == 2) return true;
        }
        return false;
    }

    private void updateCatalogStatus() {
        if (catalogStatus == null) return;
        if (catalogRoot == null) {
            catalogStatus.setText("Catálogo: no cargado");
            return;
        }
        String hash = catalogRoot.optString("Hash", "");
        if (hash.length() > 12) hash = hash.substring(0, 12) + "…";
        catalogStatus.setText("Catálogo cargado · " + selectableSubtypes.size() + " tipologías de chapa · hash " + hash);
    }

    private void refreshOpenings() {
        if (openingsContainer == null) return;
        openingsContainer.removeAllViews();
        if (openings.isEmpty()) {
            TextView none = text("Todavía no hay aberturas cargadas.", 13, false);
            none.setPadding(0, dp(8), 0, dp(10));
            openingsContainer.addView(none);
            return;
        }
        for (int i = 0; i < openings.size(); i++) {
            final int index = i;
            Opening op = openings.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));
            TextView info = text((i + 1) + ". " + op.name + " · " + op.widthMm + "×" + op.heightMm + " mm · x" + op.quantity + "\n" + op.subtypeName, 14, false);
            row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            Button del = button("Eliminar");
            del.setOnClickListener(v -> {
                openings.remove(index);
                saveDraft();
                refreshOpenings();
            });
            row.addView(del, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            openingsContainer.addView(row, fullWidth());
        }
    }

    private void cacheCatalog(String json) {
        try (FileOutputStream fos = openFileOutput(CATALOG_CACHE, MODE_PRIVATE)) {
            fos.write(json.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    private void loadCachedCatalog() {
        try (FileInputStream fis = openFileInput(CATALOG_CACHE)) {
            String json = readAll(fis);
            JSONObject root = new JSONObject(json);
            if ("GRUPO_IDEA_CATALOG_GIC".equalsIgnoreCase(root.optString("Formato", ""))) {
                catalogRoot = root;
            }
        } catch (Exception ignored) { }
    }

    private void saveDraft() {
        try {
            JSONArray arr = new JSONArray();
            for (Opening op : openings) arr.put(op.toJson());
            try (FileOutputStream fos = openFileOutput(DRAFT_CACHE, MODE_PRIVATE)) {
                fos.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { }
    }

    private void loadDraft() {
        try (FileInputStream fis = openFileInput(DRAFT_CACHE)) {
            JSONArray arr = new JSONArray(readAll(fis));
            openings.clear();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) openings.add(Opening.fromJson(o));
            }
        } catch (Exception ignored) { }
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) throw new IllegalStateException("No se pudo abrir el archivo.");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) >= 0) sb.append(buf, 0, n);
        }
        return sb.toString();
    }

    private int parsePositive(EditText e, String field) {
        try {
            int v = Integer.parseInt(e.getText().toString().trim());
            if (v <= 0) throw new NumberFormatException();
            return v;
        } catch (Exception ex) {
            toast("Ingresá un valor válido para " + field + ".");
            e.requestFocus();
            return -1;
        }
    }

    private TextView section(String s) {
        TextView t = text(s, 18, true);
        t.setPadding(0, dp(18), 0, dp(8));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, true);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(28, 37, 48));
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    private EditText input(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setText(value);
        return e;
    }

    private EditText numeric(String hint, String value) {
        EditText e = input(hint, value);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setSelectAllOnFocus(true);
        return e;
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private String safeName(String s) {
        if (s == null || s.trim().isEmpty()) return "Proyecto_movil";
        return s.trim().replaceAll("[^a-zA-Z0-9._-]+", "_");
    }
}
