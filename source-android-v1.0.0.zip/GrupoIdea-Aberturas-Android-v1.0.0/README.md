# Grupo Idea Aberturas Android 1.0.0

Aplicación Android compañera de **Grupo Idea Cotizador Integral v5.5**.

## Qué hace esta versión

1. Importa el catálogo `.gic` exportado por el programa de escritorio.
2. Verifica `Formato = GRUPO_IDEA_CATALOG_GIC`.
3. Lee `Hash`, `Settings` y las `Tipologias` del mismo catálogo.
4. Prioriza tipologías que tengan una parte `Geometria = 2` (`ChapaConformada`).
5. Permite cargar múltiples aberturas con nombre, ancho, alto y cantidad.
6. Guarda el catálogo importado y el borrador de aberturas en el almacenamiento interno de la app.
7. Exporta un `.gip` con:
   - `Formato = GRUPO_IDEA_PROJECT_GIP`
   - `VersionEsquema = 6`
   - `CatalogVersion = 3`
   - `CatalogHash = Hash` del `.gic` importado
   - `SubtipoId` original del catálogo
   - snapshot de `Settings`
   - lista completa de `Tipos`
8. El `.gip` se abre desde **Archivo → Abrir proyecto (.gip)** en el Cotizador Integral.

## Regla de compatibilidad

Para que el escritorio no muestre **"Catálogo diferente"**, debe tener activo el mismo `.gic` que se importó en el teléfono. El proyecto puede abrir igualmente si el hash no coincide, pero el escritorio mostrará la advertencia y conviene revisar la fabricación.

## Compilación

Proyecto nativo Java sin AndroidX ni dependencias runtime externas.

- Android Studio / Gradle 8.x
- Android Gradle Plugin 8.7.3
- compileSdk 35
- minSdk 26 (Android 8.0)
- targetSdk 35

Abrir la carpeta raíz en Android Studio y ejecutar **Build → Generate App Bundles or APKs → Generate APKs**.

APK debug esperado:
`app/build/outputs/apk/debug/app-debug.apk`

## Validación rápida del GIP

`python tools/validate_gip.py archivo.gip`

## Contrato revisado contra el escritorio v5.5

El generador se basó directamente en `Catalog.SaveProyecto`, `ProyectoDTO`, `TipologiaDTO` y `GlobalSettingsDTO` del proyecto de escritorio v5.5. No utiliza un formato inventado ni un conversor intermedio.

## Compilación automatizada

Se incluye `.github/workflows/build-apk.yml` para compilar el APK en GitHub Actions y `scripts/BUILD_APK_WINDOWS.ps1` para equipos Windows con Gradle instalado. Ver `COMPILAR_APK.md`.
