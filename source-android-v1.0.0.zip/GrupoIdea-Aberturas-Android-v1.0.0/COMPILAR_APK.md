# Cómo compilar el APK

## Opción A — Android Studio (recomendada)

1. Instalar Android Studio.
2. Abrir esta carpeta como proyecto.
3. Esperar la sincronización de Gradle.
4. Si Android Studio lo solicita, instalar Android SDK 35 / Build Tools 35.0.0.
5. Elegir **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
6. El archivo se genera en:
   `app/build/outputs/apk/debug/app-debug.apk`

Requisitos del proyecto: Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compileSdk 35.

## Opción B — GitHub Actions

El repositorio incluye `.github/workflows/build-apk.yml`.
Al subir el proyecto a GitHub, la acción instala Java/Android/Gradle, compila el APK y lo publica como artefacto `GrupoIdea-Aberturas-debug`.
También se puede ejecutar manualmente desde **Actions → Build Android APK → Run workflow**.

## Opción C — PowerShell

Si `gradle` 8.9 está instalado y disponible en PATH:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\BUILD_APK_WINDOWS.ps1
```

## Prueba de compatibilidad

1. En el Cotizador Integral de PC, exportar el catálogo `.gic` actual.
2. Instalar/abrir la app Android.
3. Importar ese `.gic`.
4. Crear una abertura.
5. Exportar un `.gip`.
6. En PC abrirlo mediante **Archivo → Abrir proyecto (.gip)**.
7. Verificar que no aparezca `Catálogo diferente`; si aparece, activar/importar en PC exactamente el mismo `.gic` usado en Android.
